
library(tseries)
library(MTS)
library(ppcor)
library(TSA)
library(forecast)
library(ggplot2)

library(magrittr)
library(readxl)
library(tidyverse)
library(plot.matrix)

## Model fitting packages:
library(glmnet)
library(mvtnorm)
library(multivar)
library(BigVAR)
library(expm)
library(gridExtra)

load("101_Data.RData")

##################################################
##################################################
##################################################
eval_forecast <- function(Y_forecast, B_est_list, range, horizon) {
  
  n <- length(Y_forecast)
  
  #msfe <- numeric(horizon)
  msfe <- matrix(0, ncol = n, nrow = horizon)
  for (h in 1:horizon) {
    
    bysubj_msfe <- numeric(n)
    for (k in 1:n) {
      Y <- Y_forecast[[k]]
      B <- B_est_list[[k]] %^% h
      
      Z <- Y[h + 1:(range - h),]
      X <- Y[1:(range - h),]
      
      err_mat <- Z - X %*% t(B)
      
      bysubj_msfe[k] <- sqrt(mean(err_mat^2))
      
    }
    msfe[h,] <- bysubj_msfe
    
  }
  
  rownames(msfe) <- paste0("msfe_step", 1:h)
  
  return(msfe)
  
}
##################################################
##################################################
##################################################

Tsamp <- 50
dfn_list <- df_list %>% 
  lapply(function(x) {
    x %>%
      dplyr::filter(t %in% 1:Tsamp) %>%
      dplyr::select(-t,-sub) %>%
      mutate_if(is.numeric, scale) %>%
      return()
  })


Y_forecast <- list()
for(i in 1:length(df_list)) {
  
  Y_forecast[[i]] <- df_list[[i]][-(1:Tsamp),] %>% 
    tibble() %>%
    dplyr::select(-sub,-t) %>% 
    as.matrix() 

}


##################################################
##################################################
##################################################
##################################################
##################################################
##################################################
## MOD-VAR with only individual structure:
Rcpp::sourceCpp("../042_modvar/matrix_fista.cpp")
source("../042_modvar/auxfunct.r")
source("../042_modvar/adaweights.r")
source("../042_modvar/bic.modvar.r")
source("../042_modvar/cv.modvar.r")
source("../042_modvar/ada.modvar.r")


lambdas1  <- 10^(seq(0, -5, length.out = 30))
ratios    <- 10^(seq(2, -2, length.out = 30))
cv.model <- dfn_list %>% 
  lapply(function(x) {
    x <- as.matrix(x)
    colnames(x) = NULL
    return(x)
  }) %>%
  cv.modvar(
    X = as.matrix(lcdf_norm),
    lambdas1 = lambdas1,
    ratios = ratios,
    multi = FALSE,
    cv.type = "bysubject",
    nfolds = 6)


save.image("711_Data.RData")
##################################################
##################################################
load("711_Data.RData")


library(tseries)
library(MTS)
library(ppcor)
library(TSA)
library(forecast)
library(ggplot2)

library(magrittr)
library(readxl)
library(tidyverse)
library(plot.matrix)

## Model fitting packages:
library(glmnet)
library(mvtnorm)
library(multivar)
library(BigVAR)
library(expm)
library(gridExtra)

par(mfrow = c(1,2),
    mar = c(5.1, 4.1, 4.1, 4.1))
plot(log(cv.model$eval.mat, 10), breaks = 30)
plot(cv.model$eval.mat == min(cv.model$eval.mat))
cv.model$lambda1
cv.model$ratios

cv.model$idiographic_coeffs
par(mfrow = c(2,2))
1:4 %>% 
  lapply(function(i) {
    network <- abs(cv.model$moderator_coeffs[[i]])
    name <- names(lcdf)[i+1]
    
    plot(network, main = name)
  })

summary(lcdf_norm)



cv.model$moderator_coeffs[[1]]

colnames(dfn_list[[1]])

mod_coeffs <- lapply(
  cv.model$moderator_coeffs, 
  function(x) {
    colnames(x) <- colnames(dfn_list[[1]])
    rownames(x) <- colnames(dfn_list[[1]])
    return(x)
  }
)

cv.model$joint_coeffs

joint_coeffs <- cv.model$joint_coeffs
colnames(joint_coeffs) <- colnames(dfn_list[[1]])
rownames(joint_coeffs) <- colnames(dfn_list[[1]])

mat_list <- list(
  joint = joint_coeffs,
  mod_age = mod_coeffs[[1]],
  mod_gender = mod_coeffs[[2]],
  mod_lcvol = mod_coeffs[[3]],
  mod_cnr = mod_coeffs[[4]])


# Save each matrix as a CSV named after the list element
for (nm in names(mat_list)) {
  write.csv(
    mat_list[[nm]],
    file = file.path(paste0("600_AggregatedDataReal/modmat_all/711_",nm, ".csv")),
    row.names = TRUE
  )
}


mod_coeffs[[1]] ## AGE EFFECTS
## SN_AnteriorInsula  --> FPN_dlPFC           (-)
## SN_AnteriorInsula  --> DMN_mPFC            (-)
## DMN_IPL            --> SN_AnteriorInsula   (+)

mod_coeffs[[2]] ## GENDER EFFECTS:
## NONE

mod_coeffs[[3]] ## LC VOLUME EFFECTS:
## DMN_MTL            --> DMN_PCC_Precuneus   (-)
## DMN_MTL            --> DMN_IPL             (-)
## DMN_IPL            --> DMN_MTL             (+)
## FPN_dACC_preSMA    --> DMN_MTL             (-)

mod_coeffs[[4]] ## CNR EFFECTS:
## FPN_PPC            --> DMN_MTL             (+)
## FPN_PPC            --> DMN_IPL             (+)
## DMN_mPFC           --> DMN_PCC_Precuneus   (-)
## DMN_PCC_Precuneus  --> DMN_IPL             (+)
## DMN_MTL            --> FPN_PPC             (-)

## Gene coding:
# 1) "FPN_dlPFC"
# 2) "FPN_PPC"
# 3) "FPN_dACC_preSMA"
# 4) "DMN_mPFC"
# 5) "DMN_PCC_Precuneus"
# 6) "DMN_IPL"
# 7) "DMN_MTL"
# 8) "SN_AnteriorInsula"
# 9) "SN_ACC" 


length(df_list)


cv.model$moderator_coeffs[[1]]



cv.model$eval.mat
cv.model$lambda1
cv.model$ratios

par(mfrow = c(2,2))

cv.model$bysubject_coeffs[1:4] %>%
  lapply(plot)
(fitM50$mats)$total[1:4] %>%
  lapply(plot)
B_est_list [1:4] %>%
  lapply(plot)

cv.model$moderator_coeffs
cv.model$bysubject_coeffs[[1]]
cv.model$joint_coeffs
cv.model$idiographic_coeffs[[1]]


cv.model$bysubject_coeffs[[1]] == cv.model$idiographic_coeffs[[1]]


B_estMOD50_list <- cv.model$bysubject_coeffs
B_est_list2 <- rep(ncol(df) - 2, length(df_list)) %>%
  lapply(function(x) {return(diag(x))})



apply(
  eval_forecast(Y_forecast, B_estMOD50_list, range = 100, horizon = 10),
  1, 
  mean)

str(B_estMOD50_list)

((eval_forecast(Y_forecast, B_estMOD50_list, range = 100, horizon = 10) -
    eval_forecast(Y_forecast, B_est_list2, range = 100, horizon = 10)) /
    eval_forecast(Y_forecast, B_est_list2, range = 100, horizon = 10)) %>% 
  plot(breaks = 10)


((eval_forecast(Y_forecast, B_estMOD50_list, range = 100, horizon = 10) -
    eval_forecast(Y_forecast, B_est_list2, range = 100, horizon = 10)) /
    eval_forecast(Y_forecast, B_est_list2, range = 100, horizon = 10)) %>% 
  apply(1, mean) %>%
  plot()




## Benefits compared to persistent forecasting.
rfeMOD50 <- ((eval_forecast(Y_forecast, B_estMOD50_list, range = 100, horizon = 10) -
              eval_forecast(Y_forecast, B_est_list2, range = 100, horizon = 10)) /
             eval_forecast(Y_forecast, B_est_list2, range = 100, horizon = 10)) 
p1 <- rfeMOD50 %>% 
  t() %>% as.data.frame() %>%
  tibble() %>% 
  pivot_longer(cols = msfe_step1:msfe_step10,
               names_to = "StepNo",
               names_prefix = "msfe_step",
               values_to = "error") %>%
  mutate(StepNo = factor(StepNo, levels = 1:10, ordered = TRUE)) %>%
  ggplot(aes(x = StepNo, y = error)) +
  geom_boxplot() +
  geom_hline(yintercept = 0) +
  ylim(-0.5,1) +
  ggtitle("MOD-VAR")

## Benefits compared to persistent forecasting.
rfeM50 <- ((eval_forecast(Y_forecast, B_estM50_list, range = 100, horizon = 10) -
              eval_forecast(Y_forecast, B_est_list2, range = 100, horizon = 10)) /
             eval_forecast(Y_forecast, B_est_list2, range = 100, horizon = 10)) 
p2 <- rfeM50 %>% 
  t() %>% as.data.frame() %>%
  tibble() %>% 
  pivot_longer(cols = msfe_step1:msfe_step10,
               names_to = "StepNo",
               names_prefix = "msfe_step",
               values_to = "error") %>%
  mutate(StepNo = factor(StepNo, levels = 1:10, ordered = TRUE)) %>%
  ggplot(aes(x = StepNo, y = error)) +
  geom_boxplot() +
  geom_hline(yintercept = 0) +
  ylim(-0.5,1) +
  ggtitle("Multi VAR")

## Benefits compared to persistent forecasting.
rfeVAR <- (eval_forecast(Y_forecast, B_est_list, range = 100, horizon = 10) -
             eval_forecast(Y_forecast, B_est_list2, range = 100, horizon = 10)) /
  eval_forecast(Y_forecast, B_est_list2, range = 100, horizon = 10)
p3 <- rfeVAR %>% 
  t() %>% as.data.frame() %>%
  tibble() %>% 
  pivot_longer(cols = msfe_step1:msfe_step10,
               names_to = "StepNo",
               names_prefix = "msfe_step",
               values_to = "error") %>%
  mutate(StepNo = factor(StepNo, levels = 1:10, ordered = TRUE)) %>%
  ggplot(aes(x = StepNo, y = error)) +
  geom_boxplot() +
  geom_hline(yintercept = 0) +
  ylim(-0.5,1) +
  ggtitle("VAR")


grid.arrange(p1, p2, p3, ncol = 3)



##################################################
##################################################
dMOD50 <- rfeMOD50 %>% 
  t() %>% as.data.frame() %>%
  tibble() %>% 
  pivot_longer(cols = msfe_step1:msfe_step10,
               names_to = "StepNo",
               names_prefix = "msfe_step",
               values_to = "error") %>%
  mutate(type = "MOD-VAR: FI")

dM50 <- rfeM50 %>% 
  t() %>% as.data.frame() %>%
  tibble() %>% 
  pivot_longer(cols = msfe_step1:msfe_step10,
               names_to = "StepNo",
               names_prefix = "msfe_step",
               values_to = "error") %>%
  mutate(type = "Multi-VAR")

dV50 <- rfeVAR %>% 
  t() %>% as.data.frame() %>%
  tibble() %>% 
  pivot_longer(cols = msfe_step1:msfe_step10,
               names_to = "StepNo",
               names_prefix = "msfe_step",
               values_to = "error") %>%
  mutate(type = "VAR")

perf_data <- rbind(dMOD50, dM50, dV50) %>%
  mutate(StepNo = factor(StepNo, levels = 1:10, ordered = TRUE))

head(perf_data)

ggplot(perf_data, aes(x = factor(StepNo), y = error, fill = type)) +
  geom_boxplot(position = position_dodge(width = 0.8)) +
  labs(
    x = "Step Number",
    y = "Error",
    fill = "Type"
  ) +
  theme_minimal()








##################################################
##################################################
##################################################
##################################################
##################################################
##################################################

## ALL OPTIONS OF MOD-VAR MODELS:
Rcpp::sourceCpp("041_modvar/matrix_fista.cpp")
source("041_modvar/auxfunct.r")
source("041_modvar/adaweights.r")
source("041_modvar/bic.modvar.r")
source("041_modvar/cv.modvar.r")
source("041_modvar/ada.modvar.r")

#lambdas1  <- 10^(seq(2, -2, length.out = 10)) # Best so far!
#ratios    <- 10^(seq(2, 0, length.out = 10)) 

lambdas1  <- 10^(seq(0, -5, length.out = 10)) # Best so far!
ratios    <- 10^(seq(2, -2, length.out = 10)) 

lcdf_norm <- lcdf_norm %>% 
  as.matrix()
colnames(lcdf_norm) <- NULL 
MO.model <- dfn_list %>% 
  lapply(function(x) {
    x <- as.matrix(x)
    colnames(x) = NULL
    return(x)
  }) %>%
  cv.modvar(
    X = lcdf_norm,
    lambdas1 = lambdas1,
    ratios = ratios,
    multi = FALSE,
    cv.type = "rolling")


IO.model <- dfn_list %>% 
  lapply(function(x) {
    x <- as.matrix(x)
    colnames(x) = NULL
    return(x)
  }) %>%
  cv.modvar(
    X = NULL,
    lambdas1 = lambdas1,
    ratios = ratios,
    multi = TRUE,
    cv.type = "rolling")


MI.model <- dfn_list %>% 
  lapply(function(x) {
    x <- as.matrix(x)
    colnames(x) = NULL
    return(x)
  }) %>%
  cv.modvar(
    X = lcdf_norm,
    lambdas1 = lambdas1,
    ratios = ratios,
    multi = TRUE,
    cv.type = "rolling")


save.image("BrainNetworksGeneData/102_Data.RData")
rm(list = ls())
##################################################
##################################################
## Visualizations before comparison:
load("BrainNetworksGeneData/102_Data.RData")

## Verifying correct fit conditions:
str(MO.model$idiographic_coeffs)
str(MO.model$moderator_coeffs)
str(MO.model$joint_coeffs)

str(IO.model$idiographic_coeffs)
str(IO.model$moderator_coeffs)
str(IO.model$joint_coeffs)

str(MI.model$idiographic_coeffs)
str(MI.model$moderator_coeffs)
str(MI.model$joint_coeffs)

## Are the models having the same sparsity pattern?
par(mfcol = c(3,2))
plot(log(abs(MI.model$joint_coeffs) + 1e-10, 10) > -2)
plot(log(abs(MO.model$joint_coeffs) + 1e-10, 10) > -2)
plot(log(abs(IO.model$joint_coeffs) + 1e-10, 10) > -2)

plot(MI.model$joint_coeffs == MO.model$joint_coeffs)
plot(MI.model$joint_coeffs == IO.model$joint_coeffs)


## How does the evaluation matrix look?
par(mfcol = c(3,2))
plot(log(MO.model$eval.mat, base = 10))
plot(log(IO.model$eval.mat, base = 10))
plot(log(MI.model$eval.mat, base = 10))

plot(MO.model$eval.mat == min(MO.model$eval.mat))
plot(IO.model$eval.mat == min(IO.model$eval.mat))
plot(MI.model$eval.mat == min(MI.model$eval.mat))



##################################################
##################################################
## Visualizing results:
B_estMO50_list <- MO.model$bysubject_coeffs
B_estIO50_list <- IO.model$bysubject_coeffs
B_estMI50_list <- MI.model$bysubject_coeffs

rfeMO50 <- ((eval_forecast(Y_forecast, B_estMO50_list, range = 100, horizon = 10) -
               eval_forecast(Y_forecast, B_est_list2, range = 100, horizon = 10)) /
              eval_forecast(Y_forecast, B_est_list2, range = 100, horizon = 10)) 
rfeIO50 <- ((eval_forecast(Y_forecast, B_estIO50_list, range = 100, horizon = 10) -
               eval_forecast(Y_forecast, B_est_list2, range = 100, horizon = 10)) /
              eval_forecast(Y_forecast, B_est_list2, range = 100, horizon = 10)) 
rfeMI50 <- ((eval_forecast(Y_forecast, B_estMI50_list, range = 100, horizon = 10) -
               eval_forecast(Y_forecast, B_est_list2, range = 100, horizon = 10)) /
              eval_forecast(Y_forecast, B_est_list2, range = 100, horizon = 10)) 


rfeM50 <- ((eval_forecast(Y_forecast, B_estM50_list, range = 100, horizon = 10) -
              eval_forecast(Y_forecast, B_est_list2, range = 100, horizon = 10)) /
             eval_forecast(Y_forecast, B_est_list2, range = 100, horizon = 10)) 

rfeVAR <- (eval_forecast(Y_forecast, B_est_list, range = 100, horizon = 10) -
             eval_forecast(Y_forecast, B_est_list2, range = 100, horizon = 10)) /
  eval_forecast(Y_forecast, B_est_list2, range = 100, horizon = 10)

#######################
#######################
## Generating plots:
dMO50 <- rfeMO50 %>% 
  t() %>% as.data.frame() %>%
  tibble() %>% 
  pivot_longer(cols = msfe_step1:msfe_step10,
               names_to = "StepNo",
               names_prefix = "msfe_step",
               values_to = "error") %>%
  mutate(type = "MOD-VAR: MOD")

dIO50 <- rfeMO50 %>% 
  t() %>% as.data.frame() %>%
  tibble() %>% 
  pivot_longer(cols = msfe_step1:msfe_step10,
               names_to = "StepNo",
               names_prefix = "msfe_step",
               values_to = "error") %>%
  mutate(type = "MOD-VAR: FI")

dMI50 <- rfeMO50 %>% 
  t() %>% as.data.frame() %>%
  tibble() %>% 
  pivot_longer(cols = msfe_step1:msfe_step10,
               names_to = "StepNo",
               names_prefix = "msfe_step",
               values_to = "error") %>%
  mutate(type = "MOD-VAR: MOD+FI")

dM50 <- rfeM50 %>% 
  t() %>% as.data.frame() %>%
  tibble() %>% 
  pivot_longer(cols = msfe_step1:msfe_step10,
               names_to = "StepNo",
               names_prefix = "msfe_step",
               values_to = "error") %>%
  mutate(type = "Multi-VAR")

dV50 <- rfeVAR %>% 
  t() %>% as.data.frame() %>%
  tibble() %>% 
  pivot_longer(cols = msfe_step1:msfe_step10,
               names_to = "StepNo",
               names_prefix = "msfe_step",
               values_to = "error") %>%
  mutate(type = "VAR")

perf_data <- rbind(dMO50, dIO50, dMI50,  dM50, dV50) %>%
  mutate(StepNo = factor(StepNo, levels = 1:10, ordered = TRUE))

head(perf_data)

ggplot(perf_data, aes(x = factor(StepNo), y = error, fill = type)) +
  geom_boxplot(position = position_dodge(width = 0.8)) +
  labs(
    x = "Step Number",
    y = "Error",
    fill = "Type"
  ) +
  theme_minimal()


