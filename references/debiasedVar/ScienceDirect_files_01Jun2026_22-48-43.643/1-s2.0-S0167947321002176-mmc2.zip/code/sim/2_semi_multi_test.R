library(glmnet)
# BtLasso
library(HDCI)
# JM
library(expm)
library(flare)
# LDPE
library(hdi)
# model-based BtLDPE
library(matrixcalc)
library(dqrng)
library(FinCovRegularization)
# Corr
library(RVAideMemoire)
# utility
library(parallel)
library(tictoc)
library(tidyverse)

source("fun.R")
set.seed(1234)

# job_id <- 4
# n_rep <- 2
# n_bt <- 2
# ncores <- 4


job_id <- as.numeric(commandArgs(T)[1])
n_rep <- 50
n_bt <- 100
ncores <- 28


# 1 data -----------------------------------------------------------------

load(file = "data/sp500_fit.RData")
n <- 250
k <- ncol(A)
beta <- as.vector(t(A))

# Y
simdata <- map(1:n_rep, ~ {
  init_times <- 2000
  e <- matrix(sample(e_hat, k * (n + init_times), replace = T), k, n + init_times) 
  y <- e
  for (t in 2:(n + init_times)) {
    y[, t] <- A %*% y[, t - 1, drop = F] + e[, t, drop = F]
  }
  y[, init_times:(n + init_times)]
})



# 2 inference ----------------------------------------------------------

alpha <- 0.05
met <- c("LDPE_test", "BtLDPE_test", "MultiBtLDPE_test", "Corr_test")[job_id]

tic()
res <- mclapply(simdata, met, mc.cores = ncores)
runtime <- toc() %>% unlist %>% diff %>% unname

save(runtime, res, file = str_glue("output/res/j{job_id}_res.RData"))


# 3 summary ---------------------------------------------------------------

# library(tidyverse)
# alpha <- 0.05
# load(file = "data/sp500_fit.RData")
# beta <- as.vector(t(A))
# 
# map(1:4, ~ {
#   load(file = str_glue("output/res/j{.x}_res.RData"))
#   summary_tab <- map_dfr(res, ~ {
#     n_tp <- sum(.x <= alpha & beta != 0)
#     n_fp <- sum(.x <= alpha & beta == 0)
#     n_tn <- sum(.x >  alpha & beta == 0)
#     n_fn <- sum(.x >  alpha & beta != 0)
#     fdr <- n_fp / (n_tp + n_fp)
#     recall <- n_tp / (n_tp + n_fn)
#     tibble(n_tp, n_fp, n_tn, n_fn, fdr, recall)
#   })
#   save(summary_tab, file = str_glue("output/j{.x}_sum.RData"))
# })

summary_tab <- map_dfr(res, ~ {
  n_tp <- sum(.x <= alpha & beta != 0)
  n_fp <- sum(.x <= alpha & beta == 0)
  n_tn <- sum(.x >  alpha & beta == 0)
  n_fn <- sum(.x >  alpha & beta != 0)
  fdr <- n_fp / (n_tp + n_fp)
  recall <- n_tp / (n_tp + n_fn)
  tibble(n_tp, n_fp, n_tn, n_fn, fdr, recall)
})

save(summary_tab, file = str_glue("output/j{job_id}_sum.RData"))








