library(glmnet)
library(dqrng)
# BtLasso
library(HDCI)
# JM
library(expm)
library(flare)
# LDPE
library(hdi)
# model-based BtLDPE
library(matrixcalc)
library(dqrng)
library(FinCovRegularization)
# utility
library(parallel)
library(tictoc)
library(tidyverse)

source("fun.R")
set.seed(1234)

# case_id <- 1
# met_id <- 7
# n_rep <- 4
# n_bt <- 2
# mc_bt <- 2
# n_cores <- 4

job_id <- as.numeric(commandArgs(T)[1])
n_rep <- 500
n_bt <- 100
mc_bt <- 200
job <- expand_grid(
  met_id = 1:7,
  case_id = 1:4
)[job_id,]
attach(job)
if (met_id %in% c(1, 2, 5, 6)) {
  n_cores <- 14
} else if (met_id %in% c(3, 4)){
  n_cores <- 7
} else {
  n_cores <- 24
}

# 1 data -----------------------------------------------------------------

k <- 100
setup <- expand_grid(
  n = c(100, 150),
  error = c("cauchy", "t2"),
  s = 3,
  lambda_max = 0.6
)[case_id, ]
attach(setup)

# A
a_s0 <- runif(s * k, -0.5, 0.5)
a_s <- a_s0 + sign(a_s0) * 0.5
A0 <- matrix(0, k, k)
for (i in 1:k) {
  a0 <- sample(c(a_s[((i - 1) * s + 1):(i * s - 1)], rep(0, k - s)), k - 1)
  A0[i, ] <- append(a0, a_s[i * s], after = i - 1)
}
spec_rad <- Mod(eigen(A0, symmetric = F, only.values = T)$values)[1]
A <- A0 * lambda_max / spec_rad
beta <- as.vector(t(A))
# round(range(abs(beta[beta!=0])), 2)

# Y
simdata <- map(1:n_rep, ~ {
  init_times <- 2000
  if (error == "cauchy") {
    e <- matrix(rt(k * (n + init_times), 1), k, n + init_times)
  } else if (error == "t2") {
    e <- matrix(rt(k * (n + init_times), 2), k, n + init_times)
  }
  y <- e
  for (t in 2:(n + init_times)) {
    y[, t] <- A %*% y[, t - 1, drop = F] + e[, t, drop = F]
  }
  y[, init_times:(n + init_times)]
})

detach(setup)


# 2 inference ----------------------------------------------------------

alpha <- 0.05
met <- c("BtLasso", "BtLassoOLS", "JM", "LDPE", "BtLDPE", "MultiBtLDPE", "ModelBtLDPE")[met_id]
met_fun <- switch(met_id, BtLasso, BtLassoOLS, JM, LDPE, BtLDPE, MultiBtLDPE, ModelBtLDPE)

tic()
res <- mcmapply(function(yt, rep_id) {
  out <- met_fun(yt)
  if (rep_id %in% round(n_rep * c(1 / 4, 2 / 4, 3 / 4, 1))) {
    save(rep_id, file = str_glue("output/progress/m{met_id}_c{case_id}_{rep_id}.RData"))
  }
  out
}, simdata, 1:length(simdata), SIMPLIFY = F, mc.cores = n_cores)
runtime <- toc() %>% unlist %>% diff %>% unname

save(runtime, res, file = str_glue("output/res/m{met_id}_c{case_id}_res.RData"))

res_tab <- tibble(res) %>%
  mutate(rep_id = row_number()) %>% 
  unnest(res) %>% 
  group_by(rep_id) %>% 
  mutate(btype = ifelse(beta == 0, "zero", "non-zero"), b_id = row_number(), 
         b = beta, .before = everything()) %>% 
  ungroup()




# 3 summary ---------------------------------------------------------------

comp_stat <- function(data_i){
  bind_cols(
    data_i %>% 
      group_by(b_id, b) %>% 
      summarise(
        Ebhat = mean(bhat), 
        cp = mean(ci_l <= b & b <= ci_u),
        length = mean(ci_u - ci_l),
        .groups = "drop"
      ) %>% 
      summarize(
        bias = sqrt(sum((Ebhat - b)^2)),
        cp = mean(cp),
        length = mean(length),
        .groups = "drop"
      ),
    data_i %>% 
      group_by(rep_id) %>% 
      summarise(squre_err = sum((bhat - b)^2), .groups = "drop") %>% 
      summarise(rmse = sqrt(mean(squre_err)), .groups = "drop") 
  ) %>% 
    relocate(bias, rmse, cp, length)
}

comp_stat_se <- function(data_i) {
  bind_cols(
    # stat
    data_i %>% comp_stat,
    # stat_se using bootstrap
    1:mc_bt %>% 
    mclapply(function(mc_i) {
      data_i %>% 
        group_by(rep_id) %>% 
        nest() %>% 
        ungroup() %>% 
        slice_sample(prop = 1, replace = TRUE) %>% 
        unnest(data) %>% 
        comp_stat
    }, mc.cores = n_cores) %>% 
    map_dfr(~ .x) %>% 
      summarise(across(everything(), ~ sd(.x), .names = "{.col}_se"))
  )
}

summary_tab <- bind_rows(
  res_tab %>% 
    group_by(btype) %>% 
    nest() %>% 
    summarise(stat = map(data, comp_stat_se), .groups = "drop") %>% 
    unnest(stat),
  res_tab %>% 
    comp_stat_se() %>% 
    mutate(btype = "overall", .before = everything())
) %>% 
  mutate(case = case_id, 
         method = met,
         .before = everything()) %>% 
  mutate(time = runtime)

save(summary_tab, file = str_glue("output/m{met_id}_c{case_id}_sum.RData"))








