
# JM ----------------------------------------------------------------------
# modification: store M to reduce the amount of calculation


# Authors: Hamid Javadi, Adel Javanmard, Andrea Montanari, Sven Schmit
# Date: April 24th, 2014
#
# Confidence intervals for high-dimensional regression using the method of
# A. Javanmard, A. Montanari
# "Confidence intervals and hypothesis testing for high-dimensional regression"
# 2013, arXiv:1306.3171
#
# library(Matrix)
# library(glmnet)
# library(expm)
# library(flare)

SoftThreshold <- function( x, lambda ) {
  #
  # Standard soft thresholding
  #
  if (x>lambda){
    return (x-lambda);}
  else {
    if (x< (-lambda)){
      return (x+lambda);}
    else {
      return (0); }
  }
}

InverseLinftyOneRow <- function ( sigma, i, mu, maxiter=50, threshold=1e-2 ) {
  p <- nrow(sigma);
  rho <- max(abs(sigma[i,-i])) / sigma[i,i];
  mu0 <- rho/(1+rho);
  beta <- rep(0,p);
  
  if (mu >= mu0){
    beta[i] <- (1-mu0)/sigma[i,i];
    returnlist <- list("optsol" = beta, "iter" = 0);
    return(returnlist);
  }
  
  diff.norm2 <- 1;
  last.norm2 <- 1;
  iter <- 1;
  iter.old <- 1;
  beta[i] <- (1-mu0)/sigma[i,i];
  beta.old <- beta;
  sigma.tilde <- sigma;
  diag(sigma.tilde) <- 0;
  vs <- -sigma.tilde%*%beta;
  
  while ((iter <= maxiter) && (diff.norm2 >= threshold*last.norm2)){    
    
    for (j in 1:p){
      oldval <- beta[j];
      v <- vs[j];
      if (j==i)
        v <- v+1;    
      beta[j] <- SoftThreshold(v,mu)/sigma[j,j];
      if (oldval != beta[j]){
        vs <- vs + (oldval-beta[j])*sigma.tilde[,j];
      }
    }
    
    iter <- iter + 1;
    if (iter==2*iter.old){
      d <- beta - beta.old;
      diff.norm2 <- sqrt(sum(d*d));
      last.norm2 <-sqrt(sum(beta*beta));
      iter.old <- iter;
      beta.old <- beta;
      if (iter>10)
        vs <- -sigma.tilde%*%beta;
    }
  }
  
  returnlist <- list("optsol" = beta, "iter" = iter)
  return(returnlist)
}

InverseLinfty <- function(sigma, n, resol=1.5, mu=NULL, maxiter=50, threshold=1e-2, verbose = TRUE) {
  isgiven <- 1;
  if (is.null(mu)){
    isgiven <- 0;
  }
  
  p <- nrow(sigma);
  M <- matrix(0, p, p);
  xperc = 0;
  xp = round(p/10);
  for (i in 1:p) {
    if ((i %% xp)==0){
      xperc = xperc+10;
      if (verbose) {
        print(paste(xperc,"% done",sep="")); }
    }
    if (isgiven==0){
      mu <- (1/sqrt(n)) * qnorm(1-(0.1/(p^2)));
    }
    mu.stop <- 0;
    try.no <- 1;
    incr <- 0;
    while ((mu.stop != 1)&&(try.no<10)){
      last.beta <- beta
      output <- InverseLinftyOneRow(sigma, i, mu, maxiter=maxiter, threshold=threshold)
      beta <- output$optsol
      iter <- output$iter
      if (isgiven==1){
        mu.stop <- 1
      }
      else{
        if (try.no==1){
          if (iter == (maxiter+1)){
            incr <- 1;
            mu <- mu*resol;
          } else {
            incr <- 0;
            mu <- mu/resol;
          }
        }
        if (try.no > 1){
          if ((incr == 1)&&(iter == (maxiter+1))){
            mu <- mu*resol;
          }
          if ((incr == 1)&&(iter < (maxiter+1))){
            mu.stop <- 1;
          }
          if ((incr == 0)&&(iter < (maxiter+1))){
            mu <- mu/resol;
          }
          if ((incr == 0)&&(iter == (maxiter+1))){
            mu <- mu*resol;
            beta <- last.beta;
            mu.stop <- 1;
          }                        
        }
      }
      try.no <- try.no+1
    }
    M[i,] <- beta;
  }
  return(M)
}

NoiseSd <- function( yh, A, n ){
  ynorm <- sqrt(n)*(yh/sqrt(diag(A)));
  sd.hat0 <- mad(ynorm);
  
  zeros <- (abs(ynorm)<3*sd.hat0);
  y2norm <- sum(yh[zeros]^2);
  Atrace <- sum(diag(A)[zeros]);
  sd.hat1 <- sqrt(n*y2norm/Atrace);
  
  ratio <- sd.hat0/sd.hat1;
  if (max(ratio,1/ratio)>2)
    print("Warning: Noise estimate problematic");
  
  s0 <- sum(zeros==FALSE);
  return (list( "sd" = sd.hat1, "nz" = s0));
}


Lasso <- function( X, y, lambda = NULL, intercept = TRUE){
  #
  # Compute the Lasso estimator:
  # - If lambda is given, use glmnet and standard Lasso
  # - If lambda is not given, use square root Lasso
  #
  p <- ncol(X);
  n <- nrow(X);
  
  if  (is.null(lambda)){
    lambda <- sqrt(qnorm(1-(0.1/p))/n);
    outLas <- slim(X,y,lambda=c(lambda),method="lq",q=2,verbose=FALSE);
    # Objective : sqrt(RSS/n) +lambda *penalty
    if (intercept==TRUE) {
      return (c(as.vector(outLas$intercept),as.vector(outLas$beta)))
    }  else {
      return (as.vector(outLas$beta));
    }
  } else {
    outLas <- glmnet(X, y, family = c("gaussian"), alpha =1, intercept = intercept );
    # Objective :1/2 RSS/n +lambda *penalty
    if (intercept==TRUE){
      return (as.vector(coef(Las,s=lambda)));
    } else {
      return (as.vector(coef(Las,s=lambda))[2:(p+1)]);
    }
  }
}

# SSLasso <- function (X, y, alpha=0.05, lambda = NULL, mu = NULL, intercept = TRUE, 
#                      resol=1.3, maxiter=50, threshold=1e-2, verbose = TRUE) {
#   #
#   # Compute confidence intervals and p-values.
#   #
#   # Args:
#   #   X     :  design matrix
#   #   y     :  response
#   #   alpha :  significance level
#   #   lambda:  Lasso regularization parameter (if null, fixed by sqrt lasso)
#   #   mu    :  Linfty constraint on M (if null, searches)
#   #   resol :  step parameter for the function that computes M
#   #   maxiter: iteration parameter for computing M
#   #   threshold : tolerance criterion for computing M
#   #   verbose : verbose?
#   #
#   # Returns:
#   #   noise.sd: Estimate of the noise standard deviation
#   #   norm0   : Estimate of the number of 'significant' coefficients
#   #   coef    : Lasso estimated coefficients
#   #   unb.coef: Unbiased coefficient estimates
#   #   low.lim : Lower limits of confidence intervals
#   #   up.lim  : upper limit of confidence intervals
#   #   pvals   : p-values for the coefficients						 
#   #
#   p <- ncol(X);
#   n <- nrow(X);
#   pp <- p;
#   col.norm <- 1/sqrt((1/n)*diag(t(X)%*%X));
#   X <- X %*% diag(col.norm);
#   
#   htheta <- Lasso (X,y,lambda=lambda,intercept=intercept);
#   
#   if (intercept==TRUE){
#     Xb <- cbind(rep(1,n),X);
#     col.norm <- c(1,col.norm);
#     pp <- (p+1);
#   } else {
#     Xb <- X;
#   }
#   sigma.hat <- (1/n)*(t(Xb)%*%Xb);
#   
#   if ((n>=2*p)){
#     tmp <- eigen(sigma.hat)
#     tmp <- min(tmp$values)/max(tmp$values)
#   }else{
#     tmp <- 0
#   }
#   
#   if ((n>=2*p)&&(tmp>=1e-4)){
#     M <- solve(sigma.hat)
#   }else{
#     M <- InverseLinfty(sigma.hat, n, resol=resol, mu=mu, maxiter=maxiter, threshold=threshold, verbose=verbose);
#   }
#   
#   unbiased.Lasso <- as.numeric(htheta + (M%*%t(Xb)%*%(y - Xb %*% htheta))/n);
#   
#   A <- M %*% sigma.hat %*% t(M);
#   noise <- NoiseSd( unbiased.Lasso, A, n );
#   s.hat <- noise$sd;
#   
#   interval.sizes <- qnorm(1-(alpha/2))*s.hat*sqrt(diag(A))/(sqrt(n));
#   
#   if  (is.null(lambda)){
#     lambda <- s.hat*sqrt(qnorm(1-(0.1/p))/n);
#   }
#   
#   addlength <- rep(0,pp);
#   MM <- M%*%sigma.hat - diag(pp);
#   for (i in 1:pp){
#     effectivemuvec <- sort(abs(MM[i,]),decreasing=TRUE);
#     effectivemuvec <- effectivemuvec[0:(noise$nz-1)];
#     addlength[i] <- sqrt(sum(effectivemuvec*effectivemuvec))*lambda;
#   }  
#   
#   htheta <- htheta*col.norm;
#   unbiased.Lasso <- unbiased.Lasso*col.norm;
#   interval.sizes <- interval.sizes*col.norm;
#   addlength <- addlength*col.norm;
#   
#   if (intercept==TRUE){
#     htheta <- htheta[2:pp];
#     unbiased.Lasso <- unbiased.Lasso[2:pp];
#     interval.sizes <- interval.sizes[2:pp];
#     addlength <- addlength[2:pp];
#   }  
#   p.vals <- 2*(1-pnorm(sqrt(n)*abs(unbiased.Lasso)/(s.hat*col.norm[(pp-p+1):pp]*sqrt(diag(A[(pp-p+1):pp,(pp-p+1):pp])))))
#   
#   returnList <- list("noise.sd" = s.hat,
#                      "norm0" = noise$nz,
#                      "coef" = htheta,
#                      "unb.coef" = unbiased.Lasso,
#                      "low.lim" = unbiased.Lasso - interval.sizes - addlength,
#                      "up.lim" = unbiased.Lasso + interval.sizes + addlength,
#                      "pvals" = p.vals
#   )
#   return(returnList)
# }

SSLasso_return_M <- function (X, y, alpha=0.05, lambda = NULL, mu = NULL, intercept = TRUE, 
                     resol=1.3, maxiter=50, threshold=1e-2, verbose = TRUE) {
  #
  # Compute confidence intervals and p-values.
  #
  # Args:
  #   X     :  design matrix
  #   y     :  response
  #   alpha :  significance level
  #   lambda:  Lasso regularization parameter (if null, fixed by sqrt lasso)
  #   mu    :  Linfty constraint on M (if null, searches)
  #   resol :  step parameter for the function that computes M
  #   maxiter: iteration parameter for computing M
  #   threshold : tolerance criterion for computing M
  #   verbose : verbose?
  #
  # Returns:
  #   M
  p <- ncol(X);
  n <- nrow(X);
  pp <- p;
  col.norm <- 1/sqrt((1/n)*diag(t(X)%*%X));
  X <- X %*% diag(col.norm);
  
  if (intercept==TRUE){
    Xb <- cbind(rep(1,n),X);
    col.norm <- c(1,col.norm);
    pp <- (p+1);
  } else {
    Xb <- X;
  }
  sigma.hat <- (1/n)*(t(Xb)%*%Xb);
  
  if ((n>=2*p)){
    tmp <- eigen(sigma.hat)
    tmp <- min(tmp$values)/max(tmp$values)
  }else{
    tmp <- 0
  }
  
  if ((n>=2*p)&&(tmp>=1e-4)){
    M <- solve(sigma.hat)
  }else{
    M <- InverseLinfty(sigma.hat, n, resol=resol, mu=mu, maxiter=maxiter, 
                       threshold=threshold, verbose=verbose);
  }
  M
}



SSLasso_with_M <- function (X, y, M, alpha=0.05, lambda = NULL, mu = NULL, intercept = TRUE, 
                     resol=1.3, maxiter=50, threshold=1e-2, verbose = TRUE) {
  #
  # Compute confidence intervals and p-values.
  #
  # Args:
  #   X     :  design matrix
  #   y     :  response
  #   M
  #   alpha :  significance level
  #   lambda:  Lasso regularization parameter (if null, fixed by sqrt lasso)
  #   mu    :  Linfty constraint on M (if null, searches)
  #   resol :  step parameter for the function that computes M
  #   maxiter: iteration parameter for computing M
  #   threshold : tolerance criterion for computing M
  #   verbose : verbose?
  #
  # Returns:
  #   noise.sd: Estimate of the noise standard deviation
  #   norm0   : Estimate of the number of 'significant' coefficients
  #   coef    : Lasso estimated coefficients
  #   unb.coef: Unbiased coefficient estimates
  #   low.lim : Lower limits of confidence intervals
  #   up.lim  : upper limit of confidence intervals
  #   pvals   : p-values for the coefficients						 
  #
  p <- ncol(X);
  n <- nrow(X);
  pp <- p;
  col.norm <- 1/sqrt((1/n)*diag(t(X)%*%X));
  X <- X %*% diag(col.norm);
  
  htheta <- Lasso (X,y,lambda=lambda,intercept=intercept);
  
  if (intercept==TRUE){
    Xb <- cbind(rep(1,n),X);
    col.norm <- c(1,col.norm);
    pp <- (p+1);
  } else {
    Xb <- X;
  }
  sigma.hat <- (1/n)*(t(Xb)%*%Xb);
  
  # if ((n>=2*p)){
  #   tmp <- eigen(sigma.hat)
  #   tmp <- min(tmp$values)/max(tmp$values)
  # }else{
  #   tmp <- 0
  # }
  # 
  # if ((n>=2*p)&&(tmp>=1e-4)){
  #   M <- solve(sigma.hat)
  # }else{
  #   M <- InverseLinfty(sigma.hat, n, resol=resol, mu=mu, maxiter=maxiter, threshold=threshold, verbose=verbose);
  # }
  
  unbiased.Lasso <- as.numeric(htheta + (M%*%t(Xb)%*%(y - Xb %*% htheta))/n);
  
  A <- M %*% sigma.hat %*% t(M);
  noise <- NoiseSd( unbiased.Lasso, A, n );
  s.hat <- noise$sd;
  
  interval.sizes <- qnorm(1-(alpha/2))*s.hat*sqrt(diag(A))/(sqrt(n));
  
  if  (is.null(lambda)){
    lambda <- s.hat*sqrt(qnorm(1-(0.1/p))/n);
  }
  
  addlength <- rep(0,pp);
  MM <- M%*%sigma.hat - diag(pp);
  for (i in 1:pp){
    effectivemuvec <- sort(abs(MM[i,]),decreasing=TRUE);
    effectivemuvec <- effectivemuvec[0:(noise$nz-1)];
    addlength[i] <- sqrt(sum(effectivemuvec*effectivemuvec))*lambda;
  }  
  
  htheta <- htheta*col.norm;
  unbiased.Lasso <- unbiased.Lasso*col.norm;
  interval.sizes <- interval.sizes*col.norm;
  addlength <- addlength*col.norm;
  
  if (intercept==TRUE){
    htheta <- htheta[2:pp];
    unbiased.Lasso <- unbiased.Lasso[2:pp];
    interval.sizes <- interval.sizes[2:pp];
    addlength <- addlength[2:pp];
  }  
  p.vals <- 2*(1-pnorm(sqrt(n)*abs(unbiased.Lasso)/(s.hat*col.norm[(pp-p+1):pp]*sqrt(diag(A[(pp-p+1):pp,(pp-p+1):pp])))))
  
  returnList <- list("noise.sd" = s.hat,
                     "norm0" = noise$nz,
                     "coef" = htheta,
                     "unb.coef" = unbiased.Lasso,
                     "low.lim" = unbiased.Lasso - interval.sizes - addlength,
                     "up.lim" = unbiased.Lasso + interval.sizes + addlength,
                     "pvals" = p.vals
  )
  return(returnList)
}



# bootLasso & bootLassoOLS ---------------------------------------
# modification: replace escv.glmnet by cv.glmnet to prevent accidental error


bootLasso <- function (x, y, B = 500, type.boot = "residual", alpha = 0.05, 
          cv.method = "cv", nfolds = 10, foldid, cv.OLS = FALSE, tau = 0, 
          parallel = FALSE, standardize = TRUE, intercept = TRUE, parallel.boot = FALSE, 
          ncores.boot = 1, ...) 
{
  x <- as.matrix(x)
  y <- as.numeric(y)
  n <- dim(x)[1]
  p <- dim(x)[2]
  if ((type.boot != "residual") & (type.boot != "paired")) {
    stop("type.boot should take value of 'residual' or 'paired'.")
  }
  selectset <- rep(0, p)
  Beta <- rep(0, p)
  globalfit <- glmnet(x, y, standardize = standardize, intercept = intercept, 
                      ...)
  lambda <- globalfit$lambda
  # cvfit <- escv.glmnet(x, y, lambda = lambda, nfolds = nfolds, 
  #                      tau = tau, cv.OLS = cv.OLS, parallel = parallel, standardize = standardize, 
  #                      intercept = intercept, ...)
  # if (cv.method == "cv") {
  #   lambda.opt <- cvfit$lambda.cv
  # }
  # if (cv.method == "escv") {
  #   lambda.opt <- cvfit$lambda.escv
  # }
  # if (cv.method == "cv1se") {
  #   lambda.opt <- cvfit$lambda.cv1se
  # }
  cvfit <- cv.glmnet(x, y, nfolds = nfolds, parallel = parallel,
                     standardize = standardize, intercept = intercept)
  lambda.opt <- cvfit$lambda.min
  fitlasso <- predict(globalfit, type = "coefficients", s = lambda.opt)
  fit.value <- predict(globalfit, newx = x, s = lambda.opt)
  betalasso <- fitlasso[-1]
  Beta <- betalasso
  if (type.boot == "residual") {
    fit <- fit.value
    residual <- y - fit
    residual_center <- residual - mean(residual)
    Beta.boot <- matrix(0, nrow = B, ncol = p)
    out <- list()
    if (!parallel.boot) {
      for (i in 1:B) {
        resam <- sample(1:n, n, replace = TRUE)
        ystar <- fit + residual_center[resam]
        boot.obj <- HDCI::Lasso(x = x, y = ystar, lambda = lambda.opt, 
                          standardize = standardize, intercept = intercept, 
                          ...)
        out[[i]] <- boot.obj$beta
      }
    }
    else {
      resams <- matrix(sample(1:n, n * B, replace = TRUE), 
                       nrow = n)
      out <- foreach(i = 1:B) %dopar% {
        resam <- resams[, i]
        ystar <- fit + residual_center[resam]
        boot.obj <- HDCI::Lasso(x = x, y = ystar, lambda = lambda.opt, 
                          standardize = standardize, intercept = intercept, 
                          ...)
        boot.obj$beta
      }
    }
    for (i in 1:B) {
      Beta.boot[i, ] <- out[[i]]
      out[[i]] <- 0
    }
    out <- NULL
    interval <- ci(Beta, Beta.boot, alpha = alpha, type = "basic")
  }
  if (type.boot == "paired") {
    Beta.boot <- matrix(0, nrow = B, ncol = p)
    out <- list()
    if (!parallel.boot) {
      for (i in 1:B) {
        resam <- sample(1:n, n, replace = TRUE)
        rx <- x[resam, ]
        ry <- y[resam]
        boot.obj <- HDCI::Lasso(x = rx, y = ry, lambda = lambda.opt, 
                          standardize = standardize, intercept = intercept, 
                          ...)
        out[[i]] <- boot.obj$beta
      }
    }
    else {
      resams <- matrix(sample(1:n, n * B, replace = TRUE), 
                       nrow = n)
      out <- foreach(i = 1:B) %dopar% {
        resam <- resams[, i]
        rx <- x[resam, ]
        ry <- y[resam]
        boot.obj <- HDCI::Lasso(x = rx, y = ry, lambda = lambda.opt, 
                          standardize = standardize, intercept = intercept, 
                          ...)
        boot.obj$beta
      }
    }
    for (i in 1:B) {
      Beta.boot[i, ] <- out[[i]]
      out[[i]] <- 0
    }
    out <- NULL
    interval <- ci(Beta, Beta.boot, alpha = alpha, type = "quantile")
  }
  object <- list(lambda.opt = lambda.opt, Beta = Beta, interval = interval)
  object
}

bootLassoOLS <- function (x, y, B = 500, type.boot = "residual", alpha = 0.05, 
                          OLS = TRUE, cv.method = "cv", nfolds = 10, foldid, cv.OLS = TRUE, 
                          tau = 0, parallel = FALSE, standardize = TRUE, intercept = TRUE, 
                          parallel.boot = FALSE, ncores.boot = 1, ...) 
{
  x <- as.matrix(x)
  y <- as.numeric(y)
  n <- dim(x)[1]
  p <- dim(x)[2]
  if ((type.boot != "residual") & (type.boot != "paired")) {
    stop("type.boot should take value of 'residual' or 'paired'.")
  }
  selectset <- rep(0, p)
  Beta.Lasso <- rep(0, p)
  Beta.LassoOLS <- rep(0, p)
  globalfit <- glmnet(x, y, standardize = standardize, intercept = intercept, 
                      ...)
  lambda <- globalfit$lambda
  # cvfit <- escv.glmnet(x, y, lambda = lambda, nfolds = nfolds, 
  #                      tau = tau, cv.OLS = cv.OLS, parallel = parallel, standardize = standardize, 
  #                      intercept = intercept, ...)
  # if (cv.method == "cv") {
  #   lambda.opt <- cvfit$lambda.cv
  # }
  # if (cv.method == "escv") {
  #   lambda.opt <- cvfit$lambda.escv
  # }
  # if (cv.method == "cv1se") {
  #   lambda.opt <- cvfit$lambda.cv1se
  # }
  cvfit <- cv.glmnet(x, y, nfolds = nfolds, parallel = parallel,
                     standardize = standardize, intercept = intercept)
  lambda.opt <- cvfit$lambda.min
  fitlasso <- predict(globalfit, type = "coefficients", s = lambda.opt)
  fit.value <- predict(globalfit, newx = x, s = lambda.opt)
  betalasso <- fitlasso[-1]
  Beta.Lasso <- betalasso
  Beta.LassoOLS <- betalasso
  selectvar <- betalasso != 0
  if (OLS & sum(selectvar) > 0) {
    mls.obj <- mls(x[, selectvar, drop = FALSE], y, tau = tau, 
                   standardize = standardize, intercept = intercept)
    Beta.LassoOLS[selectvar] <- mls.obj$beta
    fit.value <- mypredict(mls.obj, newx = x[, selectvar, 
                                             drop = FALSE])
  }
  if (type.boot == "residual") {
    fit <- fit.value
    residual <- y - fit
    residual_center <- residual - mean(residual)
    Beta.boot.Lasso <- matrix(0, nrow = B, ncol = p)
    Beta.boot.LassoOLS <- matrix(0, nrow = B, ncol = p)
    out <- list()
    if (!parallel.boot) {
      for (i in 1:B) {
        out[[i]] <- list()
        resam <- sample(1:n, n, replace = TRUE)
        ystar <- fit + residual_center[resam]
        boot.obj <- HDCI::Lasso(x = x, y = ystar, lambda = lambda.opt, 
                          standardize = standardize, intercept = intercept, 
                          ...)
        out[[i]][[1]] <- boot.obj$beta
        if (OLS) {
          boot.obj <- LassoOLS(x = x, y = ystar, lambda = lambda.opt, 
                               standardize = standardize, intercept = intercept, 
                               ...)
        }
        out[[i]][[2]] <- boot.obj$beta
      }
    }
    else {
      resams <- matrix(sample(1:n, n * B, replace = TRUE), 
                       nrow = n)
      out <- foreach(i = 1:B) %dopar% {
        resam <- resams[, i]
        ystar <- fit + residual_center[resam]
        boot.obj <- HDCI::Lasso(x = x, y = ystar, lambda = lambda.opt, 
                          standardize = standardize, intercept = intercept, 
                          ...)
        beta1 <- boot.obj$beta
        if (OLS) {
          boot.obj <- LassoOLS(x = x, y = ystar, lambda = lambda.opt, 
                               standardize = standardize, intercept = intercept, 
                               ...)
        }
        beta2 <- boot.obj$beta
        list(beta1 = beta1, beta2 = beta2)
      }
    }
    for (i in 1:B) {
      Beta.boot.Lasso[i, ] <- out[[i]][[1]]
      Beta.boot.LassoOLS[i, ] <- out[[i]][[2]]
      out[[i]] <- 0
    }
    out <- NULL
    interval.Lasso <- ci(Beta.Lasso, Beta.boot.Lasso, alpha = alpha, 
                         type = "basic")
    interval.LassoOLS <- ci(Beta.LassoOLS, Beta.boot.LassoOLS, 
                            alpha = alpha, type = "basic")
  }
  if (type.boot == "paired") {
    Beta.boot.Lasso <- matrix(0, nrow = B, ncol = p)
    Beta.boot.LassoOLS <- matrix(0, nrow = B, ncol = p)
    out <- list()
    if (!parallel.boot) {
      for (i in 1:B) {
        out[[i]] <- list()
        resam <- sample(1:n, n, replace = TRUE)
        rx <- x[resam, ]
        ry <- y[resam]
        boot.obj <- HDCI::Lasso(x = rx, y = ry, lambda = lambda.opt, 
                          standardize = standardize, intercept = intercept, 
                          ...)
        out[[i]][[1]] <- boot.obj$beta
        if (OLS) {
          boot.obj <- LassoOLS(x = rx, y = ry, lambda = lambda.opt, 
                               standardize = standardize, intercept = intercept, 
                               ...)
        }
        out[[i]][[2]] <- boot.obj$beta
      }
    }
    else {
      resams <- matrix(sample(1:n, n * B, replace = TRUE), 
                       nrow = n)
      out <- foreach(i = 1:B) %dopar% {
        resam <- resams[, i]
        rx <- x[resam, ]
        ry <- y[resam]
        boot.obj <- HDCI::Lasso(x = rx, y = ry, lambda = lambda.opt, 
                          standardize = standardize, intercept = intercept, 
                          ...)
        beta1 <- boot.obj$beta
        if (OLS) {
          boot.obj <- LassoOLS(x = rx, y = ry, lambda = lambda.opt, 
                               standardize = standardize, intercept = intercept, 
                               ...)
        }
        beta2 <- boot.obj$beta
        list(beta1 = beta1, beta2 = beta2)
      }
    }
    for (i in 1:B) {
      Beta.boot.Lasso[i, ] <- out[[i]][[1]]
      Beta.boot.LassoOLS[i, ] <- out[[i]][[2]]
      out[[i]] <- 0
    }
    out <- NULL
    interval.Lasso <- ci(Beta.Lasso, Beta.boot.Lasso, alpha = alpha, 
                         type = "quantile")
    interval.LassoOLS <- ci(Beta.LassoOLS, Beta.boot.LassoOLS, 
                            alpha = alpha, type = "quantile")
  }
  object <- list(lambda.opt = lambda.opt, Beta.Lasso = Beta.Lasso, 
                 Beta.LassoOLS = Beta.LassoOLS, interval.Lasso = interval.Lasso, 
                 interval.LassoOLS = interval.LassoOLS)
  object
}


# model-based bootstrap de-biased Lasso ---------------------------------------------------------------------

ic.glmnet <- function(x, y, crit = c("bic", "aic", "aicc", "hqc"), ...) {
  if (is.matrix(x) == FALSE) {
    x <- as.matrix(x)
  }
  if (is.vector(y) == FALSE) {
    y <- as.vector(y)
  }
  crit <- match.arg(crit)
  n <- length(y)
  model <- glmnet(x = x, y = y, ...)
  coef <- coef(model)
  lambda <- model$lambda
  df <- model$df
  yhat <- cbind(1, x) %*% coef
  residuals <- (y - yhat)
  mse <- colMeans(residuals^2)
  sse <- colSums(residuals^2)
  nvar <- df + 1
  bic <- n * log(mse) + nvar * log(n)
  # aic <- n * log(mse) + 2 * nvar
  # aicc <- aic + (2 * nvar * (nvar + 1)) / (n - nvar - 1)
  # hqc <- n * log(mse) + 2 * nvar * log(log(n))
  # sst <- (n - 1) * var(y)
  # r2 <- 1 - (sse / sst)
  # adjr2 <- (1 - (1 - r2) * (n - 1) / (nrow(x) - nvar - 1))
  crit <- switch(crit,
    bic = bic,
    aic = aic,
    aicc = aicc,
    hqc = hqc
  )
  selected <- best.model <- which.max(crit == min(crit))
  # ic <- c(
  #   bic = bic[selected], aic = aic[selected], aicc = aicc[selected],
  #   hqc = hqc[selected]
  # )
  result <- list(
    coefficients = coef[, selected], 
    #ic = ic, 
    lambda = lambda[selected],
    nvar = nvar[selected], glmnet = model, residuals = residuals[,selected], fitted.values = yhat[, selected], ic.range = crit,
    call = match.call()
  )
  class(result) <- "ic.glmnet"
  return(result)
}

A_de <- function(X_t, lambda_gamma = NULL, lambda_A = NULL) {
  X_t <- t(t(X_t) - apply(X_t, 2, mean))
  n <- dim(X_t)[1]
  p <- dim(X_t)[2]
  Z_t <- X_t

  Ainit <- matrix(0, p, p)
  Athr <- matrix(0, p, p)
  for (i in 1:p)
  {
    lasso.tmp <- ic.glmnet(X_t[-n, ], X_t[-1, i], crit = "bic", nlambda = 100, lambda.min.ratio = 0.01, lambda = lambda_A, intercept = FALSE)
    first.step.coef <- coef(lasso.tmp)[-1][1:p]
    penalty.factor <- 1 / abs(abs(first.step.coef) + 1 / sqrt(n))
    adalasso <- ic.glmnet(X_t[-n, ], X_t[-1, i], crit = "bic", penalty.factor = penalty.factor, nlambda = 100, lambda.min.ratio = 0.01, lambda = lambda_A, intercept = FALSE)
    Ainit[i, ] <- coef(adalasso)[-1][1:p]
    Athr[i, ] <- Ainit[i, ] * as.numeric(abs(Ainit[i, ]) >= pmax((log(p) / n)^{
      2 / 3
    }, lasso.tmp$lambda[1]))
  }

  if (max(abs(eigen(Athr)$values)) > 1 - 1 / n) {
    Athr[abs(Athr) > 1 - 1 / n] <- sign(Athr[abs(Athr) > 1 - 1 / n]) * (1 - 1 / n)

    Athr <- matrix(Athr, p, p)
    if (max(abs(eigen(Athr)$values)) > 1 - 1 / n) {
      A_max <- max(abs(eigen(Athr)$values))
      Athr <- (1 - 1 / n) / A_max * Athr
    }
  }

  sigma <- Gamma_thr(X_t[-1, ] - X_t[-n, ] %*% t(Athr), lambda_gamma = lambda_gamma)
  Gamma_0h <- Gamma_0_approx(Athr, sigma, 75)


  Betahat <- matrix(0, p, p)
  for (i in 1:p)
  {
    Betahat[-i, i] <- solve(Gamma_0h[-i, -i], Gamma_0h[-i, i])
    Z_t[, i] <- X_t[, i] - X_t[, -i] %*% Betahat[-i, i]
  }

  Ahat <- Athr + t(t(t(X_t[-1, ] - X_t[-n, ] %*% t(Athr)) %*% Z_t[-n, ]) / apply(Z_t[-n, ]^2, 2, sum))

  mean_Z_t_n <- 1 / apply(Z_t, MARGIN = 2, var, na.rm = 1)
  Betahat <- diag(p) - Betahat
  stde2 <- sqrt(diag(sigma) %*% t(mean_Z_t_n))

  stde <- sqrt(diag(sigma) %*% t(1 / sapply(1:p, function(i) {
    return(t(Betahat[, i]) %*% Gamma_0h %*% Betahat[, i])
  })))
  return(list(A_de = Ahat, stde = stde, Z_t = Z_t, Sigma = sigma, stde2 = stde2))
}

Gamma_thr <- function(X_t, lambda_gamma = NULL) {
  Y_t <- X_t
  Y_t <- t(t(Y_t) / apply(X_t, 2, sd))
  if (is.null(lambda_gamma)) {
    lambda_gamma <- threshold.cv(Y_t, method = "hard")$parameter.opt
  }

  Gamma_0h <- cov(X_t) * (abs(cor(X_t)) > lambda_gamma)
  Gamma_0hmin <- min(eigen(Gamma_0h)$values)
  p <- dim(X_t)[2]
  n <- dim(X_t)[1]
  tmp <- min(c(diag(cov(X_t)) * 0.95, log(p) / n))
  while (Gamma_0hmin < tmp) {
    Gamma_0h <- 0.05 * diag(diag(Gamma_0h)) + 0.95 * Gamma_0h
    Gamma_0hmin <- min(eigen(Gamma_0h)$values)
  }
  return(Gamma_0h)
}

Gamma_0_approx <- function(A, Sigma, h) {
  p <- dim(A)[1]
  Gamma_0 <- Sigma
  tmp <- Sigma
  for (i in 1:h)
  {
    tmp <- A %*% tmp %*% t(A)
    Gamma_0 <- Gamma_0 + tmp
  }
  return(Gamma_0)
}


A_init_0 <- function(X_t, lambda_gamma = NULL, G = NULL, lambda_A = NULL) {
  X_t <- t(t(X_t) - apply(X_t, 2, mean))
  n <- dim(X_t)[1]
  p <- dim(X_t)[2]

  C_low <- matrix(-Inf, p, p)
  if (!is.null(G)) {
    k <- dim(G)[1]
    for (s in 1:k) {
      for (r in 1:k) {
        C_low[G[s, 1], G[r, 2]] <- 0
      }
    }
  }


  Ainit <- matrix(0, p, p)
  Athr <- matrix(0, p, p)
  for (i in 1:p)
  {
    lasso.tmp <- ic.glmnet(x = X_t[-n, ], y = X_t[-1, i], crit = "bic", nlambda = 100, lambda = lambda_A, lower.limits = C_low[i, ], upper.limits = -C_low[i, ], lambda.min.ratio = 0.01, intercept = FALSE)
    tau <- 1
    first.step.coef <- coef(lasso.tmp)[-1][1:p]
    penalty.factor <- (abs(first.step.coef) + 1 / sqrt(n))^(-tau)
    adalasso <- ic.glmnet(X_t[-n, ], X_t[-1, i], crit = "bic", penalty.factor = penalty.factor, nlambda = 100, lower.limits = C_low[i, ], upper.limits = -C_low[i, ], lambda = lambda_A, intercept = FALSE)
    Ainit[i, ] <- coef(adalasso)[-1][1:p]
    Athr[i, ] <- Ainit[i, ] * as.numeric(abs(Ainit[i, ]) >= pmax((log(p) / n)^{
      2 / 3
    }, lasso.tmp$lambda[1]))
  }

  if (max(abs(eigen(Athr)$values)) > 1 - 1 / n) {
    Athr[abs(Athr) > 1 - 1 / n] <- sign(Athr[abs(Athr) > 1 - 1 / n]) * (1 - 1 / n)

    Athr <- matrix(Athr, p, p)
    if (max(abs(eigen(Athr)$values)) > 1 - 1 / n) {
      A_max <- max(abs(eigen(Athr)$values))
      Athr <- (1 - 1 / n) / A_max * Athr
    }
  }

  sigma <- Gamma_thr(X_t[-1, ] - X_t[-n, ] %*% t(Athr), lambda_gamma = lambda_gamma)
  return(list(Athr = Athr, sigma = sigma, Ainit = Ainit))
}


rmvnorm2 <- function(n, sigma) {
  Sigma_chol <- {
    ev <- eigen(sigma, symmetric = TRUE)
    if (!all(ev$values >= -sqrt(.Machine$double.eps) * abs(ev$values[1]))) {
      warning("sigma is numerically not positive semidefinite")
    }
    t(ev$vectors %*% (t(ev$vectors) * sqrt(pmax(
      ev$values,
      0
    ))))
  }
  p <- dim(sigma)[1]
  eps_t <- array(dqrnorm(n * p), c(n, p))
  #eps_t <- array(rnorm((n) * p), c(n, p))
  eps_t <- eps_t %*% t(Sigma_chol)
  return(eps_t)
}

simulateVARs <- function(A, Sigma, n, n2 = 100) {
  p <- dim(A)[2]
  eps_t <- rmvnorm2(n + n2, Sigma)
  #eps_t <- mvrnorm(n + n2, mu = rep(0, p), Sigma = Sigma)
  X_t <- array(0, c(n + n2, p))
  X_t[1, ] <- eps_t[1, ]
  for (t in 2:(n + n2)) {
    X_t[t, ] <- A %*% X_t[t - 1, ] + eps_t[t, ]
  }
  return(X_t[-(1:n2), ])
}



# CIs for VAR --------------------------------------------------------------

BtLasso <- function(yt) {
  n <- ncol(yt) - 1
  k <- nrow(yt)
  X <- t(yt[, 1:n])
  map_dfr(1:k, ~ {
    Y <- yt[.x, 2:(n + 1)]
    fit <- bootLasso(x = X, y = Y, B = n_bt, alpha = alpha, intercept = F)
    tibble(
      bhat = fit$Beta, 
      ci_l = fit$interval[1,],
      ci_u = fit$interval[2,]
    )
  })
}

BtLassoOLS <- function(yt) {
  n <- ncol(yt) - 1
  k <- nrow(yt)
  X <- t(yt[, 1:n])
  map_dfr(1:k, ~ {
    Y <- yt[.x, 2:(n + 1)]
    fit <- bootLassoOLS(x = X, y = Y, B = n_bt, alpha = alpha, intercept = F,
                        cv.OLS = F)
    tibble(
      bhat = fit$Beta.LassoOLS, 
      ci_l = fit$interval.LassoOLS[1,],
      ci_u = fit$interval.LassoOLS[2,]
    )
  })
}

JM <- function(yt) {
  n <- ncol(yt) - 1
  k <- nrow(yt)
  X <- t(yt[, 1:n])
  Y <- yt[1, 2:(n + 1)]
  M <- SSLasso_return_M(X = X, y = Y, alpha = alpha, intercept = F, verbose = F)
  map_dfr(1:k, ~ {
    Y <- yt[.x, 2:(n + 1)]
    fit <- SSLasso_with_M(X = X, y = Y, M = M, alpha = alpha, intercept = F, 
                          verbose = F)
    tibble(
      bhat = fit$unb.coef, 
      ci_l = fit$low.lim,
      ci_u = fit$up.lim
    )
  })
}

LDPE <- function(yt) {
  n <- ncol(yt) - 1
  k <- nrow(yt)
  X <- t(yt[, 1:n])
  Y <- yt[1, 2:(n + 1)]
  fit1 <- lasso.proj(x = X, y = Y, return.Z = T, suppress.grouptesting = T)
  bind_rows(
    tibble(
      bhat = as.vector(fit1$bhat), 
      ci_l = unname(confint(fit1, level = 1 - alpha)[, 1]),
      ci_u = unname(confint(fit1, level = 1 - alpha)[, 2])
    ),
    map_dfr(2:k, ~ {
      Y <- yt[.x, 2:(n + 1)]
      fit <- lasso.proj(x = X, y = Y, Z = fit1$Z, suppress.grouptesting = T)
      tibble(
        bhat = as.vector(fit$bhat), 
        ci_l = unname(confint(fit, level = 1 - alpha)[, 1]),
        ci_u = unname(confint(fit, level = 1 - alpha)[, 2])
      )
    })
  )
}

BtLDPE <- function(yt) {
  n <- ncol(yt) - 1
  k <- nrow(yt)
  X <- t(yt[, 1:n])
  Y <- yt[1, 2:(n + 1)]
  fit1 <- boot.lasso.proj(x = X, y = Y, B = n_bt, boot.shortcut = T,
                          return.bootdist = T, return.Z = T, 
                          multiplecorr.method = "bonferroni")
  bind_rows(
    tibble(
      bhat = as.vector(fit1$bhat), 
      ci_l = unname(confint(fit1, level = 1 - alpha)[, 1]),
      ci_u = unname(confint(fit1, level = 1 - alpha)[, 2])
    ),
    map_dfr(2:k, ~ {
      Y <- yt[.x, 2:(n + 1)]
      fit <- boot.lasso.proj(x = X, y = Y, B = n_bt, boot.shortcut = T,
                             return.bootdist = T, Z = fit1$Z, 
                             multiplecorr.method = "bonferroni")
      tibble(
        bhat = as.vector(fit$bhat), 
        ci_l = unname(confint(fit, level = 1 - alpha)[, 1]),
        ci_u = unname(confint(fit, level = 1 - alpha)[, 2])
      )
    })
  )
}

MultiBtLDPE <- function(yt) {
  n <- ncol(yt) - 1
  k <- nrow(yt)
  X <- t(yt[, 1:n])
  Y <- yt[1, 2:(n + 1)]
  fit1 <- boot.lasso.proj(x = X, y = Y, B = n_bt, boot.shortcut = T,
                          return.bootdist = T, return.Z = T, 
                          multiplecorr.method = "bonferroni",
                          wild = T)
  bind_rows(
    tibble(
      bhat = as.vector(fit1$bhat), 
      ci_l = unname(confint(fit1, level = 1 - alpha)[, 1]),
      ci_u = unname(confint(fit1, level = 1 - alpha)[, 2])
    ),
    map_dfr(2:k, ~ {
      Y <- yt[.x, 2:(n + 1)]
      fit <- boot.lasso.proj(x = X, y = Y, B = n_bt, boot.shortcut = T,
                             return.bootdist = T, Z = fit1$Z, 
                             multiplecorr.method = "bonferroni",
                             wild = T)
      tibble(
        bhat = as.vector(fit$bhat), 
        ci_l = unname(confint(fit, level = 1 - alpha)[, 1]),
        ci_u = unname(confint(fit, level = 1 - alpha)[, 2])
      )
    })
  )
}


ModelBtLDPE <- function(yt) {
  n <- ncol(yt) - 1
  k <- nrow(yt)
  A_int <- A_init_0(t(yt))
  A_de_tmp <- A_de(t(yt))
  bhat <- as.vector(t(A_de_tmp$A_de))
  sehat <- as.vector(t(A_de_tmp$stde))
  T_boot <- sapply(1:n_bt, function(iii) {
    yts <- simulateVARs(A_int$Athr, A_int$sigma, n + 1, n2 = 200)
    A_de_tmp2 <- A_de(yts)
    bhat_star <- as.vector(t(A_de_tmp2$A_de))
    se_star <- as.vector(t(A_de_tmp2$stde))
    ((bhat_star - bhat) / se_star)
  })
  q_star <- T_boot %>% apply(1, function(Tstat) {
    quantile(Tstat, c(alpha / 2, 1 - alpha / 2), names = F)
  })
  tibble(
    bhat = bhat, 
    sehat = sehat,
    q1 = q_star[1,],
    q2 = q_star[2,],
  ) %>% 
    mutate(
      ci_l = bhat - sehat * q2,
      ci_u = bhat - sehat * q1
    )
}


# Multiple testing for VAR --------------------------------------------------------------

LDPE_test <- function(yt) {
  n <- ncol(yt) - 1
  k <- nrow(yt)
  X <- t(yt[, 1:n])
  Y <- yt[1, 2:(n + 1)]
  fit1 <- lasso.proj(x = X, y = Y, return.Z = T, multiplecorr.method = "WY",
                     suppress.grouptesting = T)
  c(
    unname(fit1$pval.corr),
    map(2:k, ~ {
      Y <- yt[.x, 2:(n + 1)]
      fit <- lasso.proj(x = X, y = Y, Z = fit1$Z, multiplecorr.method = "WY",
                        suppress.grouptesting = T)
      unname(fit$pval.corr)
    }) %>% flatten_dbl()
  )
}

BtLDPE_test <- function(yt) {
  n <- ncol(yt) - 1
  k <- nrow(yt)
  X <- t(yt[, 1:n])
  Y <- yt[1, 2:(n + 1)]
  fit1 <- boot.lasso.proj(x = X, y = Y, B = n_bt, boot.shortcut = T,
                          return.bootdist = T, return.Z = T, 
                          multiplecorr.method = "WY")
  c(
    unname(fit1$pval.corr),
    map(2:k, ~ {
      Y <- yt[.x, 2:(n + 1)]
      fit <- boot.lasso.proj(x = X, y = Y, B = n_bt, boot.shortcut = T,
                             return.bootdist = T, Z = fit1$Z, 
                             multiplecorr.method = "WY")
      unname(fit$pval.corr)
    }) %>% flatten_dbl()
  )
}

MultiBtLDPE_test <- function(yt) {
  n <- ncol(yt) - 1
  k <- nrow(yt)
  X <- t(yt[, 1:n])
  Y <- yt[1, 2:(n + 1)]
  fit1 <- boot.lasso.proj(x = X, y = Y, B = n_bt, boot.shortcut = T,
                          return.bootdist = T, return.Z = T, 
                          multiplecorr.method = "WY", wild = T)
  c(
    unname(fit1$pval.corr),
    map(2:k, ~ {
      Y <- yt[.x, 2:(n + 1)]
      fit <- boot.lasso.proj(x = X, y = Y, B = n_bt, boot.shortcut = T,
                             return.bootdist = T, Z = fit1$Z, 
                             multiplecorr.method = "WY", wild = T)
      unname(fit$pval.corr)
    }) %>% flatten_dbl()
  )
}

Corr_test <- function(yt) {
  n <- ncol(yt) - 1
  k <- nrow(yt)
  yt0 <- yt[,1:n] %>% t %>% as.data.frame
  yt1 <- yt[,2:(n + 1)] %>% t %>% as.data.frame
  map(1:k, ~ {
    multtest.cor(yt0, yt1[[.x]], ordered = F)$tab$P.value
  }) %>% flatten_dbl()
}
