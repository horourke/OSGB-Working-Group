library(parallel)
library(tidyverse)
library(hdi)
source("fun.R")
load("data/sp500_tidy.RData")

# job_id <- 3
# n_bt <- 10
# n_cores <- 4
# yt_trans <- t(as.matrix(yt))[1:10,]

job_id <- as.numeric(commandArgs(T)[1])
n_bt <- 100
n_cores <- 20
yt_trans <- t(as.matrix(yt))


# LDPE, BtLDPE, MultiBtLDPE --------------------------------------------------------------------

alpha <- 0.05

if (job_id == 1) {
  runtime <- system.time(res <- LDPE(yt_trans, parallel = T, n_cores = n_cores))[3]
} else if (job_id == 2) {
  runtime <- system.time(res <- BtLDPE(yt_trans, parallel = T, n_cores = n_cores))[3]
} else {
  runtime <- system.time(res <- MultiBtLDPE(yt_trans, parallel = T, n_cores = n_cores))[3]
}

save(res, runtime, file = str_glue("output/m{job_id}_rd_ci.RData"))



