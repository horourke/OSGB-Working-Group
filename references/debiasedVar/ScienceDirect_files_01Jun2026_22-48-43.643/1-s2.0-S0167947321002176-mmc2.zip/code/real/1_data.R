library(tidyverse)
library(tidyquant)
library(parallel)
library(glmnet)
set.seed(1234)


# 1 download --------------------------------------------------------------

sp500 <- tq_index("SP500")
sp500$symbol[which(sp500$symbol == "BRK.B")] <- "BRK-B"
sp500$symbol[which(sp500$symbol == "BF.B")] <- "BF-B"
sp500_prices_2019 <- tq_get(sp500$symbol,
  get = "stock.prices",
  from = " 2019-01-01", to = "2020-01-01"
)
save(sp500, sp500_prices_2019, file = "data/sp500.RData")

# 2 wrangling --------------------------------------------------------------

load("data/sp500.RData")
yt <- sp500_prices_2019 %>%
  filter(!(symbol %in% names(which(table(sp500_prices_2019$symbol) != 252)))) %>%
  select(symbol, date, adjusted) %>%
  group_by(symbol) %>%
  mutate(return = adjusted / lag(adjusted) - 1) %>%
  select(-adjusted) %>%
  pivot_wider(names_from = symbol, values_from = return) %>%
  filter(!is.na(AAPL)) %>%
  select(-date) %>%
  as.data.frame()
save(yt, file = "data/sp500_tidy.RData")


# 3 fitting ---------------------------------------------------------------

load("data/sp500_tidy.RData")

VAR_data <- list()
n <- nrow(yt)
p <- ncol(yt)
for (i in 1:p) {
  VAR_data[[i]] <- list(X = as.matrix(yt[1:(n - 1), ]), Y = as.matrix(yt[2:n, i]))
}

fit_lasso <- function(dataset) {
  cv.glmnet(dataset$X, dataset$Y) %>%
    coef(s = "lambda.min") %>%
    as.vector() %>%
    .[-1]
}

res <- mclapply(VAR_data, fit_lasso, mc.cores = ncores)

A <- res %>%
  unlist() %>%
  matrix(length(res), p, byrow = T)

e_hat0 <- map2(VAR_data, res, ~ .x$Y - .x$X %*% .y) %>% unlist()
e_hat <- e_hat0 - mean(e_hat0)

save(A, e_hat, file = "data/sp500_fit.RData")




# 4 visualization -------------------------------------------------------

load("data/sp500_fit.RData")

sum(A != 0) / 500

qqnorm(e_hat)
qqline(e_hat)

qqplot.t <- function(x, dof, print = FALSE) {
  length.x <- length(x)
  range.x <- range(x)
  seq.line <- seq(range.x[1], range.x[2], by = 0.01)

  theoretical.quantiles <- qt(((1:length.x) - 0.5) / length.x, df = dof)
  sample.quantiles <- sort(x)

  plot(theoretical.quantiles, sample.quantiles, xlab = "Theoretical quantiles", ylab = "Sample quantiles")
  lines(seq.line, seq.line, col = "black", lwd = 2)

  if (print == TRUE) {
    output <- list()

    output$theoretical <- theoretical.quantiles
    output$sample <- sample.quantiles

    output
  }
}

pdf(file = "chart/sp500_qq.pdf")
qqplot.t(scale(e_hat), 5)
dev.off()

