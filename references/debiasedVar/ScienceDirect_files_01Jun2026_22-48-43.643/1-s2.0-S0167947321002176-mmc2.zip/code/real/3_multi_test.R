library(expm)
library(flare)
library(glmnet)
library(hdi)
library(HDCI)
library(RVAideMemoire)
library(tidyverse)
library(parallel)
load("data/sp500_tidy.RData")
ncores <- 28


# multiple testing --------------------------------------------------------

n_bt <- 500
alpha <- 0.05

ymat <- yt %>% as.matrix %>% t

#ymat <- ymat[1:5,]; ncores <- 4; n_bt <- 10 # test

LDPE_test2 <- function (yt, corr) {
  n <- ncol(yt) - 1
  k <- nrow(yt)
  X <- t(yt[, 1:n])
  Y <- yt[1, 2:(n + 1)]
  fit1 <- lasso.proj(x = X, y = Y, return.Z = T, multiplecorr.method = corr,
                     suppress.grouptesting = T, 
                     parallel = T, ncores = ncores)
  bind_rows(
    tibble(
      y = names(fit1$pval.corr)[1],
      x = names(fit1$pval.corr),
      p_corr = unname(fit1$pval.corr)
    ),
    map_dfr(2:k, ~ {
      Y <- yt[.x, 2:(n + 1)]
      fit <- lasso.proj(x = X, y = Y, Z = fit1$Z, multiplecorr.method = corr,
                        suppress.grouptesting = T,
                        parallel = T, ncores = ncores)
      tibble(
        y = names(fit$pval.corr)[.x],
        x = names(fit$pval.corr),
        p_corr = unname(fit$pval.corr)
      )
    })
  )
}

BtLDPE_test2 <- function (yt, corr) {
  n <- ncol(yt) - 1
  k <- nrow(yt)
  X <- t(yt[, 1:n])
  Y <- yt[1, 2:(n + 1)]
  fit1 <- boot.lasso.proj(x = X, y = Y, B = n_bt, boot.shortcut = T,
                          return.bootdist = T, return.Z = T, 
                          multiplecorr.method = corr, 
                          parallel = T, ncores = ncores)
  bind_rows(
    tibble(
      y = names(fit1$pval.corr)[1],
      x = names(fit1$pval.corr),
      p_corr = unname(fit1$pval.corr)
    ),
    map_dfr(2:k, ~ {
      Y <- yt[.x, 2:(n + 1)]
      fit <- boot.lasso.proj(x = X, y = Y, B = n_bt, boot.shortcut = T,
                             return.bootdist = T, Z = fit1$Z, 
                             multiplecorr.method = corr, 
                             parallel = T, ncores = ncores)
      tibble(
        y = names(fit$pval.corr)[.x],
        x = names(fit$pval.corr),
        p_corr = unname(fit$pval.corr)
      )
    })
  )
}

MultiBtLDPE_test2 <- function (yt, corr) {
  n <- ncol(yt) - 1
  k <- nrow(yt)
  X <- t(yt[, 1:n])
  Y <- yt[1, 2:(n + 1)]
  fit1 <- boot.lasso.proj(x = X, y = Y, B = n_bt, boot.shortcut = T,
                          return.bootdist = T, return.Z = T, 
                          multiplecorr.method = corr, wild = T,
                          parallel = T, ncores = ncores)
  bind_rows(
    tibble(
      y = names(fit1$pval.corr)[1],
      x = names(fit1$pval.corr),
      p_corr = unname(fit1$pval.corr)
    ),
    map_dfr(2:k, ~ {
      Y <- yt[.x, 2:(n + 1)]
      fit <- boot.lasso.proj(x = X, y = Y, B = n_bt, boot.shortcut = T,
                             return.bootdist = T, Z = fit1$Z, 
                             multiplecorr.method = corr, wild = T,
                             parallel = T, ncores = ncores)
      tibble(
        y = names(fit$pval.corr)[.x],
        x = names(fit$pval.corr),
        p_corr = unname(fit$pval.corr)
      )
    })
  )
}

res <- map(1:3, function(i) {
  map(c("bonferroni", "BH", "BY", "WY"), function(j) {
    switch(i,
      LDPE_test2(ymat, j),
      BtLDPE_test2(ymat, j),
      MultiBtLDPE_test2(ymat, j)
    )
  })
})

save(res, file = "output/testing.RData")


# correlation multiple testing -------------------------------------------

yt0df <- yt %>% slice(1:(nrow(yt) - 1))
yt1df <- yt %>% slice(2:nrow(yt))

corr_test_res <- mclapply(c("bonferroni", "BH", "BY"), function(adj_met) {
  map_dfr(1:ncol(yt), ~ {
    corr_p <- multtest.cor(yt0df, yt1df[[.x]], ordered = F, 
                           p.method = adj_met)
    tibble(
      x = colnames(yt),
      y = colnames(yt)[.x],
      p_corr = corr_p$tab$P.value
    )
  })
}, mc.cores = 3)


save(corr_test_res, file = "output/testing_supp.RData")







