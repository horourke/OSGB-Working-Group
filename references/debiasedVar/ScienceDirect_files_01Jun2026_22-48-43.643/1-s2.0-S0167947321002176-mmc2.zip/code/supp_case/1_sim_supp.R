# R version 3.4.0 (2017-04-21)
# Platform: x86_64-pc-linux-gnu (64-bit)
# Running under: CentOS release 6.9 (Final)
# 
# Matrix products: default
# BLAS: /opt/R/lib64/R/lib/libRblas.so
# LAPACK: /opt/R/lib64/R/lib/libRlapack.so
# 
# locale:
#     [1] LC_CTYPE=zh_CN.UTF-8       LC_NUMERIC=C              
# [3] LC_TIME=zh_CN.UTF-8        LC_COLLATE=zh_CN.UTF-8    
# [5] LC_MONETARY=zh_CN.UTF-8    LC_MESSAGES=zh_CN.UTF-8   
# [7] LC_PAPER=zh_CN.UTF-8       LC_NAME=C                 
# [9] LC_ADDRESS=C               LC_TELEPHONE=C            
# [11] LC_MEASUREMENT=zh_CN.UTF-8 LC_IDENTIFICATION=C       
# 
# attached base packages:
#     [1] stats     graphics  grDevices utils     datasets  methods   base     
# 
# loaded via a namespace (and not attached):
#     [1] compiler_3.4.0




# for test

# # Job index
# job_index <- 2
# # set the numeber of cores
# ncores <- 2
# # Set test parameters
# sim_times <- 2
# bt_times <- 2


# Set dir
.libPaths('/data/user38/Rlib')
# Job index
job_index <- as.numeric(commandArgs(T)[1])
# set the number of cores
ncores <- 14
# Set parameters
sim_times <- 1000
bt_times <- 500



# Load packages
pkgs <- c("MASS","doParallel","glmnet","hdi","HDCI","expm","flare")
lapply(pkgs, function(x){library(x, character.only = T)})
source("JM.R")





# 1. Data -----------------------------------------------------------------

setup.all <- expand.grid(c(150, 201, 250), c(1,2))
names(setup.all) <- c("n","e_type")
setup <- setup.all[job_index,]
attach(setup)

p <- 200
s <- 3
lambda_max <- 0.6

set.seed(1234)

# A
a_s0 <- runif(s * p, -0.5, 0.5)
a_s <- a_s0 + sign(a_s0) * 0.5
A0 <- matrix(0,p,p)
for (i in 1:p) {
    a0 <- sample(c(a_s[((i-1)*s+1):(i*s-1)], rep(0,p-s)), p-1)
    A0[i,] <- append(a0, a_s[i*s], after = i-1)
}
spec_rad <- Mod(eigen(A0, symmetric = F, only.values = T)$values)[1]
A <- A0 * lambda_max / spec_rad

# range(abs(A)[A!=0])


# Y
dim_sel <- 1
Sig_e <- diag(1,p)
init_times <- 2000

sim_data <- list()
for (i in 1:sim_times) {
    gaussian_e <- matrix(rnorm(p * (n + init_times)), p, n + init_times)
    sub_gaussian_e <- matrix(runif(p * (n + init_times), -1, 1), p, n + init_times)
    switch(e_type,
           e <- gaussian_e,
           e <- sub_gaussian_e)
    y <- e
    for (t in 2:(n + init_times)) {
        y[,t] <- A %*% as.matrix(y[,t-1]) + e[,t]
    }
    Y_ori <- y[,(1 + init_times):(n + init_times)]
    X <- t(y[,init_times:(n - 1 + init_times)]) # n by p matrix
    Y <- Y_ori[1,] # length n vector, only consider first var
    sim_data[[i]] <- list(X=X,Y=Y)
}
detach(setup)

beta <- A[1,] # only consider first var





# 2. Methods --------------------------------------------------------------

cv_nfolds <- 10
alpha <- 0.05 # significance

BtLasso <- function (dataset) {
    fit <- bootLasso(x = dataset$X, y = dataset$Y, B = bt_times, alpha = alpha, 
                     nfolds = cv_nfolds, intercept = F)
    return(data.frame(beta_hat = fit$Beta, 
                      ci_l = fit$interval[1,],
                      ci_u = fit$interval[2,]))
}

BtLassoOLS <- function (dataset) {
    fit <- bootLassoOLS(x = dataset$X, y = dataset$Y, B = bt_times, alpha = alpha, 
                            nfolds = cv_nfolds, intercept = F, cv.OLS = T)
    return(data.frame(beta_hat = fit$Beta.LassoOLS, 
                      ci_l = fit$interval.LassoOLS[1,],
                      ci_u = fit$interval.LassoOLS[2,]))
}

JM <- function (dataset) {
    fit <- SSLasso(X = dataset$X, y = dataset$Y, alpha = alpha, intercept = F)
    return(data.frame(beta_hat = fit$unb.coef, 
                      ci_l = fit$low.lim,
                      ci_u = fit$up.lim))
}

LDPE <- function (dataset) {
    fit <- lasso.proj(x = dataset$X, y = dataset$Y, return.Z = F,
                      suppress.grouptesting = T, robust = F)
    return(data.frame(beta_hat = as.vector(fit$bhat), 
                      ci_l = confint(fit, level = 1-alpha)[,1],
                      ci_u = confint(fit, level = 1-alpha)[,2]))
}

BtLDPE <- function (dataset) {
    fit <- boot.lasso.proj(x = dataset$X, y = dataset$Y, B = bt_times, 
                           boot.shortcut = T, return.bootdist = T, return.Z = F,
                           multiplecorr.method = "bonferroni", robust = F,
                           wild = F)
    return(data.frame(beta_hat = as.vector(fit$bhat), 
                      ci_l = confint(fit, level = 1-alpha)[,1],
                      ci_u = confint(fit, level = 1-alpha)[,2]))
}


MultiBtLDPE <- function (dataset) {
    fit <- boot.lasso.proj(x = dataset$X, y = dataset$Y, B = bt_times, 
                           boot.shortcut = T, return.bootdist = T, return.Z = F,
                           multiplecorr.method = "bonferroni", robust = F,
                           wild = T)
    return(data.frame(beta_hat = as.vector(fit$bhat), 
                      ci_l = confint(fit, level = 1-alpha)[,1],
                      ci_u = confint(fit, level = 1-alpha)[,2]))
}



# 3. Computation ----------------------------------------------------------

# for test
# met_name_est <- c("Lasso", "LassoOLS", "LDPE", "LDPE1", "LDPE2")
# met_name <- c("BtLasso", "BtLassoOLS", "LDPE", "BtLDPE", "MultiBtLDPE")

met_name_est <- c("Lasso", "LassoOLS", "JM", "LDPE", "LDPE1", "LDPE2")
met_name <- c("BtLasso", "BtLassoOLS", "JM", "LDPE", "BtLDPE", "MultiBtLDPE")
run_method <- function(CI_method) {
    runtime <- system.time(est_and_CI <- mclapply(sim_data, CI_method, mc.cores = ncores) )[3]
    #save(job_index, file = paste0("progress/", "job", job_index, "_", CI_method))
    list(runtime = runtime, est_and_CI = est_and_CI)
}

registerDoParallel(cores = ncores)
infer_and_time <- lapply(met_name, run_method)

runtimes <- sapply(infer_and_time, function(x) x$runtime)
results <- lapply(infer_and_time, function(x) x$est_and_CI)


save(
    setup,
    beta,
    results,
    runtimes,
    met_name_est,
    met_name,
    file = paste0("output/hdcivar-",job_index,".RData"),
    version = c(2, 3)
)

