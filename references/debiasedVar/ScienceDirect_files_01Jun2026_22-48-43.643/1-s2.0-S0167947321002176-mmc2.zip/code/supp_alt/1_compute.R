# test

# # Job index
# job_index <- 3
# # set the numeber of cores
# ncores <- 4
# # Set test parameters
# sim_times <- 2
# bt_times <- 2
# # Load packages
# pkgs <- c("MASS","doParallel","glmnet","hdi","HDCI","expm")
# lapply(pkgs, function(x){library(x, character.only = T)})
# source("alt_methods.R")
# met_name <- c("LDPE", "LDPE_alt_cv", "LDPE_alt_bic", "LDPE_alt_sig")




# Set dir
.libPaths("/data/user38/Rlib")
# Job index
job_index <- as.numeric(commandArgs(T)[1])
# set the number of cores
ncores <- 28
# Set parameters
sim_times <- 1000
bt_times <- 500
# Load packages
pkgs <- c("MASS", "doParallel", "glmnet", "hdi", "HDCI", "expm", "flare")
lapply(pkgs, function(x) {
  library(x, character.only = T)
})
source("JM.R")
source("alt_methods.R")
met_name <- c("LDPE", "LDPE_alt_cv", "LDPE_alt_bic", "LDPE_alt_sig")


# 1. Data -----------------------------------------------------------------

n <- 100
p <- 200
s <- 3
lambda_max <- 0.6

set.seed(1234)

# A
a_s0 <- runif(s * p, -0.5, 0.5)
a_s <- a_s0 + sign(a_s0) * 0.5
A0 <- matrix(0,p,p)
for (i in 1:p) {
  a0 <- sample(c(a_s[((i-1)*s+1):(i*s-1)], rep(0,p-s)), p-1)
  A0[i,] <- append(a0, a_s[i*s], after = i-1)
}
spec_rad <- Mod(eigen(A0, symmetric = F, only.values = T)$values)[1]
A <- A0 * lambda_max / spec_rad

# range(abs(A)[A!=0])


# Y
dim_sel <- 1
Sig_e <- diag(1,p)
init_times <- 2000

sim_data <- list()
for (i in 1:sim_times) {
  e <- matrix(rt(p * (n + init_times), 2), p, n + init_times)
  y <- e
  for (t in 2:(n + init_times)) {
    y[,t] <- A %*% as.matrix(y[,t-1]) + e[,t]
  }
  Y_ori <- y[,(1 + init_times):(n + init_times)]
  X <- t(y[,init_times:(n - 1 + init_times)]) # n by p matrix
  Y <- Y_ori[1,] # length n vector, only consider first var
  sim_data[[i]] <- list(X=X,Y=Y)
}

beta <- A[1,] # only consider first var



# 2. Methods --------------------------------------------------------------

cv_nfolds <- 10
alpha <- 0.05 # significance

BtLasso <- function(dataset) {
  fit <- bootLasso(
    x = dataset$X, y = dataset$Y, B = bt_times, alpha = alpha,
    nfolds = cv_nfolds, intercept = F
  )
  return(data.frame(
    beta_hat = fit$Beta,
    ci_l = fit$interval[1, ],
    ci_u = fit$interval[2, ]
  ))
}

BtLassoOLS <- function(dataset) {
  fit <- bootLassoOLS(
    x = dataset$X, y = dataset$Y, B = bt_times, alpha = alpha,
    nfolds = cv_nfolds, intercept = F, cv.OLS = T
  )
  return(data.frame(
    beta_hat = fit$Beta.LassoOLS,
    ci_l = fit$interval.LassoOLS[1, ],
    ci_u = fit$interval.LassoOLS[2, ]
  ))
}

JM <- function(dataset) {
  fit <- SSLasso(X = dataset$X, y = dataset$Y, alpha = alpha, intercept = F)
  return(data.frame(
    beta_hat = fit$unb.coef,
    ci_l = fit$low.lim,
    ci_u = fit$up.lim
  ))
}

LDPE <- function(dataset) {
  fit <- lasso.proj(
    x = dataset$X, y = dataset$Y, return.Z = F,
    suppress.grouptesting = T, robust = F
  )
  return(data.frame(
    beta_hat = as.vector(fit$bhat),
    ci_l = confint(fit, level = 1 - alpha)[, 1],
    ci_u = confint(fit, level = 1 - alpha)[, 2]
  ))
}

BtLDPE <- function(dataset) {
  fit <- boot.lasso.proj(
    x = dataset$X, y = dataset$Y, B = bt_times,
    boot.shortcut = T, return.bootdist = T, return.Z = F,
    multiplecorr.method = "bonferroni", robust = F,
    wild = F
  )
  return(data.frame(
    beta_hat = as.vector(fit$bhat),
    ci_l = confint(fit, level = 1 - alpha)[, 1],
    ci_u = confint(fit, level = 1 - alpha)[, 2]
  ))
}


MultiBtLDPE <- function(dataset) {
  fit <- boot.lasso.proj(
    x = dataset$X, y = dataset$Y, B = bt_times,
    boot.shortcut = T, return.bootdist = T, return.Z = F,
    multiplecorr.method = "bonferroni", robust = F,
    wild = T
  )
  return(data.frame(
    beta_hat = as.vector(fit$bhat),
    ci_l = confint(fit, level = 1 - alpha)[, 1],
    ci_u = confint(fit, level = 1 - alpha)[, 2]
  ))
}



# 3. Computation ----------------------------------------------------------


run_method <- function(CI_method) {
  runtime <- system.time(
    est_and_CI <- mclapply(sim_data, CI_method, mc.cores = ncores)
    )[3]
  list(runtime = runtime, est_and_CI = est_and_CI)
}

registerDoParallel(cores = ncores)

infer_and_time <- run_method(met_name[job_index])

runtimes <- infer_and_time$runtime
results <- infer_and_time$est_and_CI


save(
  beta,
  results,
  runtimes,
  met_name,
  file = paste0("output/hdcivar_supp_", job_index, met_name[job_index],  ".RData"),
  version = c(2, 3)
)
