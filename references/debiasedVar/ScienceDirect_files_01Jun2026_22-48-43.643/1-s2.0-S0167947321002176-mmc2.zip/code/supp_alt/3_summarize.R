library(tidyverse)

met_name <- c("LDPE", "LDPE_alt_cv","LDPE_alt_bic", "LDPE_alt_sig")


# extract one replication
extract_one_rep <- function(results_met_rep, rep_i, beta) {
  tibble(results_met_rep, beta, b_ind = 1:length(beta), rep_ind = rep_i) %>%
    mutate(
      type = if_else(beta == 0, "zero", "non-zero"),
      bias = beta_hat - beta,
      square_error = (beta_hat - beta)^2,
      cp = if_else(ci_l <= beta & beta <= ci_u, 1, 0),
      length = ci_u - ci_l
    )
}

# aggregate 1000 replication
aggregate_rep <- function(met_i) {
  load(paste0("output/hdcivar_supp_", met_i, met_name[met_i],  ".RData"))
  res <- map2(results, 1:length(results), extract_one_rep, beta = beta) %>%
    reduce(add_row) %>% 
    drop_na() %>% 
    filter(!length == Inf)
  
  # zero & non-zero
  # bias, cp, length
  res1 <- res %>%
    # average over rep
    group_by(type, b_ind) %>%
    summarise(
      bias_m = abs(mean(bias)), bias_v = var(bias) / n(),
      cp_m = mean(cp), cp_v = var(cp) / n(),
      length_m = mean(length), length_v = var(length) / n()
    ) %>%
    # average over beta
    group_by(type) %>%
    summarise(
      bias_m = mean(bias_m), bias_sd = sqrt(mean(bias_v) / n()),
      cp_m = mean(cp_m), cp_sd = sqrt(mean(cp_v) / n()),
      length_m = mean(length_m), length_sd = sqrt(mean(length_v) / n())
    ) 
  # rmse
  res2 <- res %>%
    # average over beta
    group_by(type, rep_ind) %>%
    summarise(square_error_s = sum(square_error)) %>%
    # average over rep
    group_by(type) %>%
    summarise(
      rmse_m = sqrt(mean(square_error_s)),
      rmse_sd = sd(square_error_s) / (sqrt(n()) * 2 * sqrt(mean(square_error_s)))
    )
  res12 <- res1 %>%
    left_join(res2, by = "type") %>%
    ungroup() %>%
    mutate(method = met_name[met_i])
  
  # overall
  # bias, cp, length
  res3 <- res %>%
    # average over rep
    group_by(b_ind) %>%
    summarise(
      bias_m = abs(mean(bias)), bias_v = var(bias) / n(),
      cp_m = mean(cp), cp_v = var(cp) / n(),
      length_m = mean(length), length_v = var(length) / n()
    ) %>%
    # average over beta
    ungroup() %>%
    summarise(
      bias_m = mean(bias_m), bias_sd = sqrt(mean(bias_v) / n()),
      cp_m = mean(cp_m), cp_sd = sqrt(mean(cp_v) / n()),
      length_m = mean(length_m), length_sd = sqrt(mean(length_v) / n())
    ) %>% 
    mutate(type = "overall")
  # rmse
  res4 <- res %>%
    # average over beta
    group_by(rep_ind) %>%
    summarise(square_error_s = sum(square_error)) %>%
    # average over rep
    ungroup %>%
    summarise(
      rmse_m = sqrt(mean(square_error_s)),
      rmse_sd = sd(square_error_s) / (sqrt(n()) * 2 * sqrt(mean(square_error_s)))
    ) %>% 
    mutate(type = "overall")
  res34 <- res3 %>%
    left_join(res4, by = "type") %>%
    ungroup() %>%
    mutate(method = met_name[met_i])
  
  add_row(res12, res34)
}

# aggregate methods
supp_summary <- parallel::mclapply(1:4, aggregate_rep, mc.cores = 4) %>%
  reduce(add_row) %>%
  mutate(method = factor(method, levels = met_name),
         type = factor(type, levels = c("non-zero", "zero", "overall"))) %>%
  relocate(type, method, bias_m, rmse_m, rmse_sd) %>%
  arrange(type, method)

save(supp_summary, file = "output/supp_summary.RData")

load("output/supp_summary.RData")

supp_summary %>%
  mutate(across(where(is.numeric), ~ round(.x * 1000))) %>%
  mutate(bias = paste0(bias_m, "(", bias_sd, ")"),
         rmse = paste0(rmse_m, "(", rmse_sd, ")"),
         cp = paste0(cp_m, "(", cp_sd, ")"),
         length = paste0(length_m, "(", length_sd, ")")) %>% 
  select(!ends_with("_m")) %>% 
  select(!ends_with("_sd")) %>% 
  writexl::write_xlsx(path = "output/supp_summary.xlsx")
