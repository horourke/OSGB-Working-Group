LDPE_alt_cv <- function(dataset) {
  n <- length(dataset$Y)
  # cv fit
  cvfit <- cv.glmnet(x = dataset$X, y = dataset$Y, 
                     foldid = sort(rep(seq(cv_nfolds), length = n)))
  betainit <- coef(cvfit, s = cvfit$lambda.1se)[-1]
  # sigma
  residual.vector <- dataset$Y - dataset$X %*% betainit
  sigmahat <- sqrt(sum((residual.vector)^2)/(n - sum(betainit != 0)))
  # LDPE
  fit <- lasso.proj(
    x = dataset$X, y = dataset$Y, return.Z = F,
    suppress.grouptesting = T, robust = F,
    betainit = betainit, sigma = sigmahat
  )
  return(data.frame(
    beta_hat = as.vector(fit$bhat),
    ci_l = confint(fit, level = 1 - alpha)[, 1],
    ci_u = confint(fit, level = 1 - alpha)[, 2]
  ))
}

LDPE_alt_bic <- function(dataset) {
  n <- length(dataset$Y)
  # bic fit
  fit <- glmnet(x = dataset$X, y = dataset$Y)
  BIC <- log(n)*(fit$df) - (fit$nulldev - deviance(fit))
  betainit <- coef(fit, s = fit$lambda[which.min(BIC)])[-1]
  # sigma
  residual.vector <- dataset$Y - dataset$X %*% betainit
  sigmahat <- sqrt(sum((residual.vector)^2)/(n - sum(betainit != 0)))
  # LDPE
  fit <- lasso.proj(
    x = dataset$X, y = dataset$Y, return.Z = F,
    suppress.grouptesting = T, robust = F,
    betainit = betainit, sigma = sigmahat
  )
  return(data.frame(
    beta_hat = as.vector(fit$bhat),
    ci_l = confint(fit, level = 1 - alpha)[, 1],
    ci_u = confint(fit, level = 1 - alpha)[, 2]
  ))
}

LDPE_alt_sig <- function(dataset) {
  n <- length(dataset$Y)
  # cv fit
  cvfit <- cv.glmnet(x = dataset$X, y = dataset$Y)
  betainit <- coef(cvfit, s = cvfit$lambda.1se)[-1]
  # sigma
  residual.vector <- dataset$Y - dataset$X %*% betainit
  sigmahat <- sqrt(sum((residual.vector)^2)/n)
  # LDPE
  fit <- lasso.proj(
    x = dataset$X, y = dataset$Y, return.Z = F,
    suppress.grouptesting = T, robust = F,
    betainit = betainit, sigma = sigmahat
  )
  return(data.frame(
    beta_hat = as.vector(fit$bhat),
    ci_l = confint(fit, level = 1 - alpha)[, 1],
    ci_u = confint(fit, level = 1 - alpha)[, 2]
  ))
}


# test --------------------------------------------------------------

pkgs <- c("glmnet", "hdi")
lapply(pkgs, function(x) {
  library(x, character.only = T)
})

cv_nfolds <- 10
alpha <- 0.05

generate_data <- function() {
  n <- 100
  p <- 200
  s <- 3
  lambda_max <- 0.6

  # A
  a_s0 <- runif(s * p, -0.5, 0.5)
  a_s <- a_s0 + sign(a_s0) * 0.5
  A0 <- matrix(0,p,p)
  for (i in 1:p) {
    a0 <- sample(c(a_s[((i-1)*s+1):(i*s-1)], rep(0,p-s)), p-1)
    A0[i,] <- append(a0, a_s[i*s], after = i-1)
  }
  spec_rad <- Mod(eigen(A0, symmetric = F, only.values = T)$values)[1]
  A <- A0 * lambda_max / spec_rad

  # range(abs(A)[A!=0])


  # Y
  dim_sel <- 1
  Sig_e <- diag(1,p)
  init_times <- 2000

  sim_data <- list()
  sim_times <- 1
  for (i in 1:sim_times) {
    e <- matrix(runif(p * (n + init_times), -1, 1), p, n + init_times)
    y <- e
    for (t in 2:(n + init_times)) {
      y[,t] <- A %*% as.matrix(y[,t-1]) + e[,t]
    }
    Y_ori <- y[,(1 + init_times):(n + init_times)]
    X <- t(y[,init_times:(n - 1 + init_times)]) # n by p matrix
    Y <- Y_ori[1,] # length n vector, only consider first var
    sim_data[[i]] <- list(X=X,Y=Y)
  }
  sim_data[[1]]
}
dataset <- generate_data()

LDPE_alt_cv(dataset)
LDPE_alt_bic(dataset)
LDPE_alt_sig(dataset)
