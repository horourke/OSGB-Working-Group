ic.glmnet=function (x, y, crit = c("bic", "aic", "aicc", "hqc"), ...) 
{
  if (is.matrix(x) == FALSE) {
    x = as.matrix(x)
  }
  if (is.vector(y) == FALSE) {
    y = as.vector(y)
  }
  crit = match.arg(crit)
  n = length(y)
  model = glmnet(x = x, y = y, ...)
  coef = coef(model)
  lambda = model$lambda
  df = model$df
  yhat = cbind(1, x) %*% coef
  residuals = (y - yhat)
  mse = colMeans(residuals^2)
  sse = colSums(residuals^2)
  nvar = df + 1
  bic = n * log(mse) + nvar * log(n)
  aic = n * log(mse) + 2 * nvar
  aicc = aic + (2 * nvar * (nvar + 1))/(n - nvar - 1)
  hqc = n * log(mse) + 2 * nvar * log(log(n))
  sst = (n - 1) * var(y)
  r2 = 1 - (sse/sst)
  adjr2 = (1 - (1 - r2) * (n - 1)/(nrow(x) - nvar - 1))
  crit = switch(crit, bic = bic, aic = aic, aicc = aicc, hqc = hqc)
  selected = best.model = which.max(crit == min(crit))
  ic = c(bic = bic[selected], aic = aic[selected], aicc = aicc[selected], 
         hqc = hqc[selected])
  result = list(coefficients = coef[, selected], ic = ic, lambda = lambda[selected], 
                nvar = nvar[selected], glmnet = model, residuals = residuals[, 
                                                                             selected], fitted.values = yhat[, selected], ic.range = crit, 
                call = match.call())
  class(result) = "ic.glmnet"
  return(result)
}

A_de=compiler::cmpfun(function(X_t,lambda_gamma=NULL,lambda_A=NULL)
{
  X_t=t(t(X_t)-apply(X_t,2,mean))
  n=dim(X_t)[1]
  p=dim(X_t)[2]
  Z_t=X_t
  
  Ainit=matrix(0,p,p)
  Athr=matrix(0,p,p)
  for(i in 1:p)
  {
    lasso.tmp=ic.glmnet(X_t[-n,],X_t[-1,i],crit = "bic",nlambda=100,lambda.min.ratio=0.01,lambda=lambda_A,intercept = FALSE)
    first.step.coef=coef(lasso.tmp)[-1][1:p]
    penalty.factor=1/abs(abs(first.step.coef)+1/sqrt(n))
    adalasso=ic.glmnet(X_t[-n,],X_t[-1,i],crit="bic",penalty.factor=penalty.factor,nlambda=100,lambda.min.ratio=0.01,lambda=lambda_A,intercept = FALSE)
    Ainit[i,]=coef(adalasso)[-1][1:p]
    Athr[i,]=Ainit[i,]*as.numeric(abs(Ainit[i,])>=pmax((log(p)/n)^{2/3},lasso.tmp$lambda[1]))
  }
  
  if(max(abs(eigen(Athr)$values))>1-1/n)
  {
    Athr[abs(Athr)>1-1/n]=sign(Athr[abs(Athr)>1-1/n])*(1-1/n)
    
    Athr=matrix(Athr,p,p)
    if(max(abs(eigen(Athr)$values))>1-1/n)
    {
      
      A_max=max(abs(eigen(Athr)$values))
      Athr=(1-1/n)/A_max*Athr
    }
  }
  
  sigma=Gamma_thr(X_t[-1,]-X_t[-n,]%*%t(Athr),lambda_gamma = lambda_gamma)
  Gamma_0h=Gamma_0_approx(Athr,sigma,75)

  
  Betahat=matrix(0,p,p)
  for(i in 1:p)
  {
    Betahat[-i,i]=solve(Gamma_0h[-i,-i],Gamma_0h[-i,i])
    Z_t[,i]=X_t[,i]-X_t[,-i]%*%Betahat[-i,i]
  }
  
  Ahat=Athr+t(t(t(X_t[-1,]-X_t[-n,]%*%t(Athr))%*%Z_t[-n,])/apply(Z_t[-n,]^2,2,sum))
  
  mean_Z_t_n=1/apply(Z_t,MARGIN=2,var,na.rm=1)
  Betahat=diag(p)-Betahat
  stde2=sqrt(diag(sigma)%*%t(mean_Z_t_n))
  
  stde=sqrt(diag(sigma)%*%t(1/sapply(1:p,function(i) return(t(Betahat[,i])%*%Gamma_0h%*%Betahat[,i]))))
  return(list(A_de=Ahat,stde=stde,Z_t=Z_t,Sigma=sigma,stde2=stde2))
})

Gamma_thr=function(X_t,lambda_gamma=NULL)
{
  Y_t=X_t
  Y_t=t(t(Y_t)/apply(X_t,2,sd))
  if(is.null(lambda_gamma))
    lambda_gamma=threshold.cv(Y_t,method = "hard")$parameter.opt
  
  Gamma_0h=cov(X_t)*(abs(cor(X_t))>lambda_gamma)
  Gamma_0hmin=min(eigen(Gamma_0h)$values)
  p=dim(X_t)[2]
  n=dim(X_t)[1]
  tmp=min(c(diag(cov(X_t))*0.95,log(p)/n))
  while(Gamma_0hmin<tmp)
  {
    Gamma_0h=0.05*diag(diag(Gamma_0h))+0.95*Gamma_0h
    Gamma_0hmin=min(eigen(Gamma_0h)$values)
  }
  return(Gamma_0h)
}



Gamma_0_approx=function(A,Sigma,h)
{
  p=dim(A)[1]
  Gamma_0=Sigma
  tmp=Sigma
  for(i in 1:h)
  {
    tmp=A%*%tmp%*%t(A)
    Gamma_0=Gamma_0+tmp
  }
  return(Gamma_0)
}


A_init_0=compiler::cmpfun(function(X_t,lambda_gamma=NULL,G=NULL,lambda_A=NULL)
{
  X_t=t(t(X_t)-apply(X_t,2,mean))
  n=dim(X_t)[1]
  p=dim(X_t)[2]
  
  C_low=matrix(-Inf,p,p)
  if(!is.null(G))
  {
    k=dim(G)[1]
    for(s in 1:k)
      for(r in 1:k) 
        C_low[G[s,1],G[r,2]]=0
  }
  
  
  Ainit=matrix(0,p,p)
  Athr=matrix(0,p,p)
  for(i in 1:p)
  {
    lasso.tmp=ic.glmnet(x = X_t[-n,],y = X_t[-1,i],crit = "bic",nlambda=100,lambda=lambda_A,lower.limits = C_low[i,],upper.limits = -C_low[i,],lambda.min.ratio =0.01,intercept = FALSE)
    tau=1
    first.step.coef=coef(lasso.tmp)[-1][1:p]
    penalty.factor=(abs(first.step.coef)+1/sqrt(n))^(-tau)
    adalasso=ic.glmnet(X_t[-n,],X_t[-1,i],crit="bic",penalty.factor=penalty.factor,nlambda=100,lower.limits = C_low[i,],upper.limits = -C_low[i,],lambda=lambda_A,intercept = FALSE)
    Ainit[i,]=coef(adalasso)[-1][1:p]
    Athr[i,]=Ainit[i,]*as.numeric(abs(Ainit[i,])>=pmax((log(p)/n)^{2/3},lasso.tmp$lambda[1]))
  }
  
  if(max(abs(eigen(Athr)$values))>1-1/n)
  {
    Athr[abs(Athr)>1-1/n]=sign(Athr[abs(Athr)>1-1/n])*(1-1/n)
    
    Athr=matrix(Athr,p,p)
    if(max(abs(eigen(Athr)$values))>1-1/n)
    {
      
      A_max=max(abs(eigen(Athr)$values))
      Athr=(1-1/n)/A_max*Athr
    }
  }
  
  sigma=Gamma_thr(X_t[-1,]-X_t[-n,]%*%t(Athr),lambda_gamma = lambda_gamma)
  return(list(Athr=Athr,sigma=sigma,Ainit=Ainit))
})


test_max=compiler::cmpfun(function(A_de,se,G)
  return(max(abs(apply(G,MARGIN=1,function(i) return(A_de[i[1],i[2]])/se[i[1],i[2]])))))



rmvnorm2=function(n,sigma)
{
  Sigma_chol={
    ev <- eigen(sigma, symmetric = TRUE)
    if (!all(ev$values >= -sqrt(.Machine$double.eps) * abs(ev$values[1]))) {
      warning("sigma is numerically not positive semidefinite")
    }
    t(ev$vectors %*% (t(ev$vectors) * sqrt(pmax(ev$values, 
                                                0))))
  }
  p=dim(sigma)[1]
  #eps_t=array(dqrng::dqrnorm((n)*p),c(n,p))
  eps_t=array(rnorm((n)*p),c(n,p))
  eps_t=eps_t%*%t(Sigma_chol)
  return(eps_t)
}

simulateVARs=compiler::cmpfun(function(A,Sigma,n,n2=100)
{
  p=dim(A)[2]
  eps_t=rmvnorm2(n+n2,Sigma)
  X_t=array(0,c(n+n2,p))
  X_t[1,]=eps_t[1,]
  for(t in 2:(n+n2))
    X_t[t,]=A%*%X_t[t-1,]+eps_t[t,]
  return(X_t[-(1:n2),])
})



