# Load packages
.libPaths("/data/user38/Rlib")
pkgs <- c("MASS","doParallel","glmnet","hdi","HDCI","expm", 
          "compiler", "matrixcalc", "FinCovRegularization")
lapply(pkgs, function(x){library(x, character.only = T)})
source("KKP.R")


# 1. Data -----------------------------------------------------------------

sim_times <- 5

n <- 100
p <- 200
s <- 3
lambda_max <- 0.6

set.seed(1234)

# A
a_s0 <- runif(s * p, -0.5, 0.5)
a_s <- a_s0 + sign(a_s0) * 0.5
A0 <- matrix(0,p,p)
for (i in 1:p) {
  a0 <- sample(c(a_s[((i-1)*s+1):(i*s-1)], rep(0,p-s)), p-1)
  A0[i,] <- append(a0, a_s[i*s], after = i-1)
}
spec_rad <- Mod(eigen(A0, symmetric = F, only.values = T)$values)[1]
A <- A0 * lambda_max / spec_rad

# range(abs(A)[A!=0])


# Y
dim_sel <- 1
Sig_e <- diag(1,p)
init_times <- 2000

sim_data <- list()
X_t_all <- list()
for (i in 1:sim_times) {
  e <- matrix(rt(p * (n + init_times), 2), p, n + init_times)
  y <- e
  for (t in 2:(n + init_times)) {
    y[,t] <- A %*% as.matrix(y[,t-1]) + e[,t]
  }
  Y_ori <- y[,(1 + init_times):(n + init_times)]
  X <- t(y[,init_times:(n - 1 + init_times)]) # n by p matrix
  Y <- Y_ori[1,] # length n vector, only consider first var
  sim_data[[i]] <- list(X=X,Y=Y)
  X_t_all[[i]] <- t(Y_ori)
}

beta <- A[1,] # only consider first var

# for KKP
G <- cbind(rep(1, p), 1:p)



# 2. Methods --------------------------------------------------------------

cv_nfolds <- 10
alpha <- 0.05 # significance


LDPE <- function(dataset) {
  fit <- lasso.proj(
    x = dataset$X, y = dataset$Y, return.Z = F,
    suppress.grouptesting = T, robust = F
  )
  return(data.frame(
    beta_hat = as.vector(fit$bhat),
    ci_l = confint(fit, level = 1 - alpha)[, 1],
    ci_u = confint(fit, level = 1 - alpha)[, 2]
  ))
}

BtLDPE <- function(dataset) {
  fit <- boot.lasso.proj(
    x = dataset$X, y = dataset$Y, B = bt_times,
    boot.shortcut = T, return.bootdist = T, return.Z = F,
    multiplecorr.method = "bonferroni", robust = F,
    wild = F
  )
  return(data.frame(
    beta_hat = as.vector(fit$bhat),
    ci_l = confint(fit, level = 1 - alpha)[, 1],
    ci_u = confint(fit, level = 1 - alpha)[, 2]
  ))
}

MultiBtLDPE <- function(dataset) {
  fit <- boot.lasso.proj(
    x = dataset$X, y = dataset$Y, B = bt_times,
    boot.shortcut = T, return.bootdist = T, return.Z = F,
    multiplecorr.method = "bonferroni", robust = F,
    wild = T
  )
  return(data.frame(
    beta_hat = as.vector(fit$bhat),
    ci_l = confint(fit, level = 1 - alpha)[, 1],
    ci_u = confint(fit, level = 1 - alpha)[, 2]
  ))
}

ModelBtLDPE <- function(X_t) {
  A_de_tmp <- A_de(X_t)
  A_int <- A_init_0(X_t, G = G)
  T_boot <- sapply(1:B, function(i) {
    X_t <- matrix(simulateVARs(A_int$Athr, A_int$sigma, n, n2 = 200), 
                  ncol = p, byrow = FALSE)
    A_de_tmp2 <- A_de(X_t)
    return(test_max(A_de = A_de_tmp2$A_de, se = A_de_tmp2$stde, G = G))
  })
}

# 3. Computation ----------------------------------------------------------

B <- bt_times <- 500

runtime <- 1:4

runtime[1] <- system.time(tmp <- lapply(sim_data, LDPE))[3]
runtime[2] <- system.time(tmp <- lapply(sim_data, BtLDPE))[3]
runtime[3] <- system.time(tmp <- lapply(sim_data, MultiBtLDPE))[3]
runtime[4] <- system.time(tmp <- lapply(X_t_all, ModelBtLDPE))[3]

save(runtime, file = "output/runtime.RData", version = c(2, 3))
